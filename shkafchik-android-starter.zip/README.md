# Шкафчик — Android

Android WebView-приложение с календарём и системными напоминаниями.

## Напоминания календаря
- События и параметры повторения остаются в локальной базе `shkafchik_db`.
- Android AlarmManager планирует ближайшее напоминание независимо от состояния WebView.
- Поддерживаются напоминания в момент события и за выбранное число минут до него.
- Поддерживаются повторы: ежедневно, еженедельно, ежемесячно и ежегодно.
- Расписание восстанавливается после перезагрузки устройства и обновления приложения.
- Используются неточные системные будильники (`setAndAllowWhileIdle`): Android может доставить уведомление с небольшой задержкой, зато не требуется специальное разрешение на точные будильники.
- Для показа уведомлений пользователь должен разрешить уведомления приложению в Android.

## Сборка
GitHub Actions собирает отладочный APK вручную или при отправке изменений в `main`.

## Пока не реализовано
- Полноценный музыкальный плеер с MediaStore, фоновым сервисом и MediaSession.
- Автоматическая миграция данных из предыдущего APK: перед установкой новой версии рекомендуется сохранить JSON-резервную копию.

**Важно:** резервную копию JSON с личными данными не публиковать в репозитории.

\n## Версия 0.2.2
- Android Save As picker for JSON backup export.
- Android document picker for JSON backup import through WebView file chooser.
- Explicit system-bar insets for Android 15+.
- Additional calendar top spacing.
- Reminder resync on activity resume and exact alarms when Android grants access; inexact fallback otherwise.

\n## Версия 0.2.3
- Root-level Android system-bar insets: WebView is laid out only between status and navigation bars.
- Monochrome cabinet notification small icon.
- Exact-alarm access shortcut in Settings; inexact fallback remains when access is not granted.
- Optional persistent APK signing via GitHub Actions repository secrets: KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD.

\n## Версия 0.2.4 — исправление уведомлений
- Реализованы обработчики кнопок точных будильников и системных настроек уведомлений.
- Добавлена обработка результата runtime-разрешения POST_NOTIFICATIONS.
- Напоминания используют канал высокой важности для новых установок.
- Проверяется разрешение перед публикацией системного уведомления.
