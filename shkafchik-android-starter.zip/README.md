# Шкафчик — Android

Android WebView-приложение с календарём и системными напоминаниями.

## Напоминания календаря
- События и параметры повторения остаются в локальной базе `shkafchik_db`.
- Android AlarmManager планирует ближайшее напоминание независимо от состояния WebView.
- Поддерживаются напоминания в момент события и за выбранное число минут до него.
- Поддерживаются повторы: ежедневно, еженедельно, ежемесячно и ежегодно.
- Расписание восстанавливается после перезагрузки устройства и обновления приложения.
- Используются неточные системные будильники (`setAndAllowWhileIdle`): Android может доставить уведомление с небольшой задержкой, зато не требуется специальное разрешение на точные будильники.
- Для показа уведомлений пользователь должен разрешить уведомления приложению в Android.

## Сборка
GitHub Actions собирает отладочный APK вручную или при отправке изменений в `main`.

## Пока не реализовано
- Полноценный музыкальный плеер с MediaStore, фоновым сервисом и MediaSession.
- Автоматическая миграция данных из предыдущего APK: перед установкой новой версии рекомендуется сохранить JSON-резервную копию.

**Важно:** резервную копию JSON с личными данными не публиковать в репозитории.

\n## Версия 0.2.2
- Android Save As picker for JSON backup export.
- Android document picker for JSON backup import through WebView file chooser.
- Explicit system-bar insets for Android 15+.
- Additional calendar top spacing.
- Reminder resync on activity resume and exact alarms when Android grants access; inexact fallback otherwise.

\n## Версия 0.2.3
- Root-level Android system-bar insets: WebView is laid out only between status and navigation bars.
- Monochrome cabinet notification small icon.
- Exact-alarm access shortcut in Settings; inexact fallback remains when access is not granted.
- Optional persistent APK signing via GitHub Actions repository secrets: KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD.

\n## Версия 0.2.4 — исправление уведомлений
- Реализованы обработчики кнопок точных будильников и системных настроек уведомлений.
- Добавлена обработка результата runtime-разрешения POST_NOTIFICATIONS.
- Напоминания используют канал высокой важности для новых установок.
- Проверяется разрешение перед публикацией системного уведомления.

\n## Версия 0.2.5
- Tapping a calendar reminder opens the app and the matching event editor.
- Event time defaults to the current device time for new events.
- Replaced the Android native time dialog with a custom two-column scroll-wheel time picker.

\n## Версия 0.2.7 — исправление времени и перехода из уведомлений
- The HTML-generated notification now carries its event ID into the Android notification content intent.
- Notification taps route to the event in the calendar, including cold and warm app starts, with retry until the WebView handler is ready.
- The event time field has a direct click handler for the custom wheel picker.


## Версия 0.2.8
- Time picker overlay anchored to WebView viewport and shown on tapping the time field.
- Cancel closes without changing the selected time; Done applies the selected time and closes the picker.
- Removed duplicate click handling and added backdrop/Escape dismissal.


## Версия 0.2.9
- Restored direct click handler on the event time field to open the custom wheel picker immediately.
- Kept the picker outside the app content and all scrolling/modal containers.
- Cancel and Done explicitly close the picker; Done applies the selected time.
- Added a small home-screen build label populated from Android BuildConfig (versionName and versionCode), so it updates with each build.


## Версия 0.2.10
- Исправлено получение версии приложения: используется PackageManager, а не BuildConfig, который не генерировался в текущей конфигурации Gradle.
