const $=id=>document.getElementById(id);
(function showInstalledBuildVersion(){
 const el=$('appVersion');if(!el)return;
 let version='0.2.33';
 try{if(window.AndroidAPI&&typeof AndroidAPI.getAppVersion==='function')version=AndroidAPI.getAppVersion();}catch(e){}
 el.textContent='Версия '+version;
})();
const colors=['#D6A13B','#428AC4','#399B68','#8B69C7','#D27D69','#82909E','#D66A91','#54AFA5','#D69A65','#7B8794','#B4A0D8','#C4A484'];
const iconGroups={
 'Все':['📁','📂','📚','📖','📓','📔','🗒️','📝','📄','📑','📋','🗃️','🗄️','⭐','❤️','🔖','📅','⏰','✅','☑️','📌','💡','🎯','🔍','💼','💻','📊','💰','🧾','🏠','🛋️','🔧','🛒','🧹','🪴','🌱','🌿','🌸','🌳','🐾','📷','📸','🎥','🎵','🎧','🎮','🎨','✈️','🚗','🚲','🧳','🏕️','🌙','☀️','☁️','🔥','🏋️','🍎','🍳','🎁','🔒','🛡️','🔑','🌍','👥','📦'],
 'Документы':['📁','📂','📚','📖','📓','📔','🗒️','📝','📄','📑','📋','🗃️','🗄️','🔖'],
 'Работа':['💼','💻','📊','💰','🧾','📈','📉','🗓️','📞','📧','🖨️','🗂️'],
 'Дом':['🏠','🛋️','🔧','🛒','🧹','🧺','🪑','🛏️','🚿','🔑','📦','🪴'],
 'Творчество':['🎨','📷','📸','🎥','🎵','🎧','🎤','🎹','🎸','✏️','🖌️','🎭'],
 'Природа':['🪴','🌱','🌿','🌸','🌳','🌻','🌵','🍀','🌷','🐾','🐈','🐕'],
 'Отдых':['✈️','🚗','🚲','🧳','🏕️','🎮','🏋️','⚽','🏖️','🎬','🍿','🎲'],
 'Личное':['⭐','❤️','🔒','🛡️','🔑','📅','💡','🎯','🌙','☀️','👥','🎁']
};
let db=JSON.parse(localStorage.getItem('shkafchik_db')||'null')||{folders:[],notes:[],trash:[]};db.events=Array.isArray(db.events)?db.events:[];db.photos=Array.isArray(db.photos)?db.photos:[];db.homeOrder=db.homeOrder&&typeof db.homeOrder==='object'?db.homeOrder:{};db.homeSlots=db.homeSlots&&typeof db.homeSlots==='object'?db.homeSlots:{};db.noteColors=Array.isArray(db.noteColors)?db.noteColors:[];db.folderColors=Array.isArray(db.folderColors)?db.folderColors:[];db.eventColors=Array.isArray(db.eventColors)?db.eventColors:[];
let currentFolder=null, editingFolder=null, editingNote=null, viewingNote=null, selectedIcon='📁',selectedColor=colors[2],activeIconTab='Все',trashMode=false,allMode=false;
let selectedNoteColor='';
let layoutEditing=false,activePhotoId=null,photoReplaceTarget=null;
const save=()=>{
 localStorage.setItem('shkafchik_db',JSON.stringify(db));
 try{if(window.AndroidAPI&&typeof window.AndroidAPI.syncReminders==='function')window.AndroidAPI.syncReminders(JSON.stringify(db.events||[]));}catch(err){console.warn('Не удалось обновить системные напоминания',err);}
};
const formatDate=ts=>ts?new Date(ts).toLocaleString('ru-RU',{day:'numeric',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit'}):'—';
const uid=()=>Math.random().toString(36).slice(2,10);
// Every home photo is represented by one hidden note record. The image data stays
// in db.photos only; the note stores a stable link to avoid duplicating large base64 data.
function ensurePhotoNotes(){
 db.photos.forEach(ph=>{
  let note=db.notes.find(n=>n.id===ph.noteId || n.photoId===ph.id);
  if(!note){
   note={id:uid(),photoId:ph.id,hiddenPhotoNote:true,folderId:ph.parentId??null,title:ph.name||'Фотография',body:'',bodyHtml:'',attachments:[],createdAt:ph.createdAt||Date.now(),updatedAt:ph.createdAt||Date.now()};
   db.notes.push(note);
  }
  note.photoId=ph.id;note.hiddenPhotoNote=true;note.folderId=ph.parentId??null;
  if(!note.title||note.title==='Фотография')note.title=ph.name||'Фотография';
  ph.noteId=note.id;
 });
}
ensurePhotoNotes();
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const toast=t=>{let el=$('toast');el.textContent=t;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2100)};
let restoringNavigation=false;
function navSnapshot(){return {folder:currentFolder,all:allMode,music:$('musicScreen').classList.contains('visible'),modal:[...document.querySelectorAll('.modal-wrap.show')].map(x=>x.id)}}
function pushNavigation(){if(!restoringNavigation)history.pushState({shkafchik:navSnapshot()},'','#app')}
function openModal(id){$(id).classList.add('show');pushNavigation()}
function closeModal(id){$(id).classList.remove('show');if(!restoringNavigation)history.replaceState({shkafchik:navSnapshot()},'','#app')}
window.addEventListener('popstate',e=>{
 const st=e.state?.shkafchik;
 restoringNavigation=true;
 if(st){
  currentFolder=st.folder && db.folders.some(f=>f.id===st.folder&&!f.deletedAt)?st.folder:null;
  allMode=!!st.all;
  document.querySelectorAll('.modal-wrap').forEach(m=>m.classList.toggle('show',(st.modal||[]).includes(m.id)));
  setBottomTab(st.music?'music':'home');render();
 }else{
  document.querySelectorAll('.modal-wrap').forEach(m=>m.classList.remove('show'));
  if(currentFolder){const path=folderPath(currentFolder);currentFolder=path.length>1?path[path.length-2].id:null}
  else currentFolder=null;
  allMode=false;setBottomTab('home');render();
 }
 restoringNavigation=false;
});
// All dimmed modal overlays close when tapping outside their dialog.
document.querySelectorAll('.modal-wrap').forEach(overlay=>{
 overlay.addEventListener('click',e=>{
  if(e.target===overlay) closeModal(overlay.id);
 });
});
const translations={
 'Шкафчик':'Cabinet','Всё важное — в одном месте':'Everything important in one place',
 'Главная':'Home','Все заметки':'All notes','Музыка':'Music','В разработке':'Under development','Корзина':'Trash',
 'Мои папки':'My folders','Папки':'Folders','Заметки':'Notes',
 '＋ Папка':'+ Folder','＋ Заметка':'+ Note','＋ Создать':'+ Create',
 'Папка':'Folder','Заметка':'Note','Поиск':'Search','Настройки':'Settings',
 'Найти заметку или папку':'Find a note or folder',
 'Что создаём?':'What would you like to create?',
 'Новую папку':'New folder','Новую заметку':'New note',
 'Для заметок и других папок':'For notes and other folders',
 'Записать мысль или важную информацию':'Write down a thought or important information',
 'Отмена':'Cancel','Закрыть':'Close','Сохранить':'Save','Назад':'Back',
 'Название':'Title','Название папки':'Folder name','Название заметки':'Note title',
 'Содержание':'Content','Обычный текст':'Normal text','Заголовок':'Heading',
 'Подзаголовок':'Subheading','Размер выбранного фото':'Selected image size',
 'Фото':'Photo','Файл':'File','Автосохранение включено':'Autosave is on',
 'Сохранено автоматически':'Saved automatically',
 'В корзину':'Move to trash','Редактировать':'Edit',
 'Создана:':'Created:','Изменена:':'Modified:',
 'Выбрать любой оттенок':'Choose any color',
 'Цвет папки':'Folder color','Иконка':'Icon',
 'Удалить папку?':'Delete folder?',
 'Что сделать с её содержимым? Можно переместить заметки и вложенные папки в текущую папку. Сама папка попадёт в корзину.':'What should happen to its contents? You can move notes and subfolders to the current folder. The folder itself will be moved to the trash.',
 'Перенести содержимое':'Move contents','Удалить всё':'Delete all',
 'Резервное копирование':'Backup','Язык приложения':'App language',
 'Сохрани все папки, заметки, фотографии и вложения в один файл. Его можно будет использовать для восстановления данных.':'Save all folders, notes, photos and attachments in one file. You can use it to restore your data.',
 'Создать резервную копию':'Create backup','Скачать файл со всеми данными':'Download a file with all your data',
 'Восстановить из копии':'Restore from backup','Заменить текущие данные данными из файла':'Replace current data with data from the file',
 'Рекомендуем периодически сохранять резервную копию в отдельное место.':'We recommend keeping a backup in a separate location.',
 'В копию войдут все папки, заметки, фотографии и вложения.':'The backup will include all folders, notes, photos and attachments.',
 'Все заметки':'All notes','Поиск заметки или папки':'Search notes or folders',
 '0 папок':'0 folders','заметок':'notes','папок':'folders'
};
const originalTextNodes=new WeakMap();
function applyLanguage(){
 const lang=localStorage.getItem('shkafchik_language')||'ru';
 const select=$('languageSelect');
 if(select && select.value!==lang)select.value=lang;
 const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
 const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
 nodes.forEach(node=>{
  const parent=node.parentElement;
  if(!parent || parent.closest('#noteEditor,#viewBody,.note-card,.folder-card,input,textarea,script,style'))return;
  if(!originalTextNodes.has(node))originalTextNodes.set(node,node.nodeValue);
  const original=originalTextNodes.get(node);
  if(lang==='ru'){node.nodeValue=original;return;}
  const trim=original.trim();
  if(translations[trim])node.nodeValue=original.replace(trim,translations[trim]);
  else if(trim.startsWith('Изменена:'))node.nodeValue=original.replace('Изменена:','Modified:');
  else if(trim.startsWith('Создана:'))node.nodeValue=original.replace('Создана:','Created:');
  else node.nodeValue=original;
 });
 document.querySelectorAll('input[placeholder],textarea[placeholder]').forEach(el=>{
  if(!el.dataset.originalPlaceholder)el.dataset.originalPlaceholder=el.placeholder;
  if(lang==='ru')el.placeholder=el.dataset.originalPlaceholder;
  else{
   const map={'Название заметки':'Note title','Например, Дневник':'e.g. Journal','Начни записывать здесь…':'Start writing here…'};
   el.placeholder=map[el.dataset.originalPlaceholder]||el.dataset.originalPlaceholder;
  }
 });
 document.documentElement.lang=lang;
}
$('languageSelect').value=localStorage.getItem('shkafchik_language')||'ru';
$('languageSelect').onchange=e=>{
 localStorage.setItem('shkafchik_language',e.target.value);
 applyLanguage();
 toast(e.target.value==='en'?'Language changed to English':'Язык изменён на русский');
};


applyLanguage();
function folderPath(id){let a=[],f=db.folders.find(x=>x.id===id);while(f){a.unshift(f);f=db.folders.find(x=>x.id===f.parentId)}return a}
function renderBreadcrumb(){
 let p=folderPath(currentFolder);
 let html=`<button class="crumb ${!currentFolder?'current':''}" data-go="root">Главная</button>`;
 p.forEach((f,i)=>html+=`<span>›</span><button class="crumb ${i===p.length-1?'current':''}" data-go="${f.id}">${esc(f.name)}</button>`);
 $('breadcrumb').innerHTML=html;
 $('breadcrumb').querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>{currentFolder=b.dataset.go==='root'?null:b.dataset.go;allMode=false;render();pushNavigation()});
 const banner=$('locationBanner');
 const active=p[p.length-1];
 if(active && !allMode){
   banner.classList.remove('hidden');
   banner.style.setProperty('--folder-accent',active.color);
   banner.innerHTML=`<div class="folder-view-label">СЕЙЧАС ОТКРЫТА ПАПКА</div><div class="location-title"><span class="location-icon" style="background:${active.color}22;color:${active.color}">${active.icon}</span><span>${esc(active.name)}</span></div><div class="location-caption">Содержимое этой папки</div>`;
 } else { banner.classList.add('hidden'); banner.innerHTML=''; }
}
function getSearchFolderIds(){
 const scope=searchScope;
 if(scope==='all' || currentFolder===null)return new Set(db.folders.filter(f=>!f.deletedAt).map(f=>f.id));
 const ids=new Set([currentFolder]);
 let changed=true;
 while(changed){
   changed=false;
   db.folders.forEach(f=>{
     if(!f.deletedAt && ids.has(f.parentId) && !ids.has(f.id)){ids.add(f.id);changed=true;}
   });
 }
 return ids;
}
function render(){
 renderBreadcrumb();
 let q=$('searchInput').value.trim().toLowerCase();
 let folders=db.folders.filter(f=>f.parentId===currentFolder&&!f.deletedAt);
 let notes=db.notes.filter(n=>n.folderId===currentFolder&&!n.deletedAt&&!n.hiddenPhotoNote);
 if(allMode){folders=[];notes=db.notes.filter(n=>!n.deletedAt&&!n.hiddenPhotoNote)}
 if(q){
   const scopeIds=getSearchFolderIds();
   folders=db.folders.filter(f=>!f.deletedAt && scopeIds.has(f.id) && f.name.toLowerCase().includes(q));
   notes=db.notes.filter(n=>!n.deletedAt&&!n.hiddenPhotoNote && scopeIds.has(n.folderId) && ((n.title||'')+' '+(n.body||'')).toLowerCase().includes(q));
 }
 const foldersHeading=$('foldersHeading').parentElement;
 const notesHeading=$('notesHeading').parentElement;
 $('foldersHeading').textContent=q?'Найденные папки':'Папки и фотографии';
 const photos=(!q&&!allMode)?db.photos.filter(ph=>ph.parentId===currentFolder&&!ph.deletedAt):[];
 const orderKey=currentFolder||'root';
 const savedOrder=Array.isArray(db.homeOrder[orderKey])?db.homeOrder[orderKey]:[];
 const combined=[...folders.map(f=>({type:'folder',id:f.id,createdAt:f.createdAt||0})),...photos.map(ph=>({type:'photo',id:ph.id,createdAt:ph.createdAt||0}))];
 combined.sort((a,b)=>{const ai=savedOrder.indexOf(a.type+':'+a.id),bi=savedOrder.indexOf(b.type+':'+b.id);if(ai>=0||bi>=0)return (ai<0?999999:ai)-(bi<0?999999:bi);return a.type===b.type?(a.createdAt-b.createdAt):(a.type==='folder'?-1:1)});
 $('folderGrid').innerHTML=combined.map(item=>{
   if(item.type==='photo'){
    const ph=photos.find(x=>x.id===item.id);if(!ph)return '';
    return `<div class="photo-tile size-${[1,2,3,4].includes(Number(ph.size))?ph.size:1}" data-photo="${ph.id}" data-layout-item="photo:${ph.id}"><img src="${ph.data}" alt="${esc(ph.name||'Фотография')}" loading="lazy"></div>`;
   }
   const f=folders.find(x=>x.id===item.id);if(!f)return '';
   const path=folderPath(f.id).map(x=>x.name);
   const location=path.length>1?'Главная › '+path.slice(0,-1).map(esc).join(' › '):'Главная';
   return `<div class="folder" data-folder="${f.id}" data-layout-item="folder:${f.id}"><button class="folder-menu" data-menu="${f.id}">⋯</button><div class="folder-icon" style="background:${f.color}22;color:${f.color}">${f.icon}</div><div class="folder-name">${esc(f.name)}</div><div class="folder-meta">${db.folders.filter(x=>x.parentId===f.id&&!x.deletedAt).length} папок · ${db.notes.filter(x=>x.folderId===f.id&&!x.deletedAt&&!x.hiddenPhotoNote).length} заметок</div>${q?`<div class="folder-path">Расположение: ${location}</div>`:''}</div>`;
 }).join('');
 if(!q&&!allMode)applyHomePositions();
 $('notesHeading').textContent=q?'Найденные заметки':(allMode?'Все заметки':'Заметки');
 notes.sort((a,b)=>(Number(!!b.pinned)-Number(!!a.pinned)) || ((b.updatedAt||b.createdAt||0)-(a.updatedAt||a.createdAt||0)));
 $('notesList').innerHTML=notes.map(n=>{
   const path=folderPath(n.folderId).map(x=>x.name);
   const location=path.length?'Главная › '+path.map(esc).join(' › '):'Главная';
   return `<div class="note" ${/^#[0-9a-fA-F]{6}$/.test(n.color||'')?`style="background-color:${softNoteColor(n.color)}"`:'' }><button style="flex:1;min-width:0;border:0;background:transparent;text-align:left;padding:0;color:inherit" data-note="${n.id}"><span class="note-content"><span class="note-title">${esc(n.title||'Без названия')}</span><span class="note-preview">${esc(n.body||'Пустая заметка')}</span><span class="note-date">Изменена: ${formatDate(n.updatedAt||n.createdAt)}</span>${q?`<span class="note-path">Расположение: ${location}</span>`:''}</span></button><button class="pin-btn ${n.pinned?'pinned':''}" data-pin="${n.id}" aria-label="Закрепить заметку">${n.pinned?'★':'☆'}</button></div>`;
 }).join('');
 const showFolders=folders.length>0||photos.length>0;
 const showNotes=notes.length>0;
 foldersHeading.style.display=(q&&!showFolders)?'none':'';
 $('folderGrid').style.display=showFolders?'':'none';
 notesHeading.style.display=showNotes?'':'none';
 $('notesList').style.display=showNotes?'':'none';
 if(q && !showFolders && !showNotes){
   notesHeading.style.display='';
   $('notesHeading').textContent='Ничего не найдено';
 }
 $('folderGrid').querySelectorAll('[data-folder]').forEach(el=>el.onclick=e=>{
   if(e.target.closest('[data-menu]'))return;if(layoutEditing)return;
   currentFolder=el.dataset.folder;allMode=false;layoutEditing=false;render();pushNavigation();
 });
 $('folderGrid').querySelectorAll('[data-menu]').forEach(b=>b.onclick=e=>{e.stopPropagation();folderMenu(b.dataset.menu)});
 // Photo actions are opened only by long-press on the photo tile.
 // No separate three-dot control is rendered or bound.
 $('folderGrid').querySelectorAll('[data-photo]').forEach(el=>{
  let hold=null,didHold=false,moved=false;
  el.addEventListener('touchstart',e=>{
   if(layoutEditing)return;
   didHold=false;moved=false;
   hold=setTimeout(()=>{
    hold=null;didHold=true;
    openPhotoActions(el.dataset.photo);
   },560);
  },{passive:true});
  el.addEventListener('touchmove',()=>{
   moved=true;
   if(hold){clearTimeout(hold);hold=null}
  },{passive:true});
  ['touchend','touchcancel'].forEach(ev=>el.addEventListener(ev,()=>{
   if(hold){clearTimeout(hold);hold=null}
  },{passive:true}));
  el.addEventListener('contextmenu',e=>{
   e.preventDefault();
   if(!layoutEditing)openPhotoActions(el.dataset.photo);
  });
  el.onclick=e=>{
   if(didHold){didHold=false;e.preventDefault();e.stopPropagation();return}
   if(moved){moved=false;return}
   if(layoutEditing)return;
   const ph=db.photos.find(x=>x.id===el.dataset.photo);
   if(ph){if(!ph.noteId){ensurePhotoNotes();save()}viewNote(ph.noteId)}
  };
 });
 $('folderGrid').classList.toggle('editing',layoutEditing);
$('layoutDoneBar').hidden=!layoutEditing;
$('layoutDoneBar').classList.toggle('visible',layoutEditing);
 $('layoutEditToggle').textContent=layoutEditing?'Готово':'Изменить';
 $('layoutEditToggle').title=layoutEditing?'Перетащи папки и фотографии, затем нажми «Готово»':'Изменить расположение папок и фотографий';
 if(layoutEditing)bindHomeDrag();
 $('notesList').querySelectorAll('[data-note]').forEach(b=>b.onclick=()=>viewNote(b.dataset.note));
 // Long-press a note to open its actions (Edit / Delete).
 $('notesList').querySelectorAll('[data-note]').forEach(b=>{
   let pressTimer=null, didLongPress=false;
   const cancelPress=()=>{if(pressTimer){clearTimeout(pressTimer);pressTimer=null;}};
   b.addEventListener('touchstart',()=>{didLongPress=false;pressTimer=setTimeout(()=>{
     didLongPress=true;pressTimer=null;viewNote(b.dataset.note);
   },550);},{passive:true});
   b.addEventListener('touchend',cancelPress,{passive:true});
   b.addEventListener('touchmove',cancelPress,{passive:true});
   b.addEventListener('touchcancel',cancelPress,{passive:true});
   b.addEventListener('contextmenu',e=>{e.preventDefault();didLongPress=true;viewNote(b.dataset.note);});
   b.addEventListener('click',e=>{if(didLongPress){e.preventDefault();e.stopImmediatePropagation();didLongPress=false;}},true);
 });
 $('notesList').querySelectorAll('[data-pin]').forEach(b=>b.onclick=()=>{let n=db.notes.find(x=>x.id===b.dataset.pin);n.pinned=!n.pinned;save();render()});
 $('fab').textContent='＋ Создать';$('fab').onclick=()=>showCreateChoices();
}
let folderActionTarget=null;
function folderMenu(id){
 const f=db.folders.find(x=>x.id===id);if(!f)return;
 folderActionTarget=id;
 $('folderActionIcon').textContent=f.icon;
 $('folderActionIcon').style.background=f.color+'22';
 $('folderActionIcon').style.color=f.color;
 $('folderActionName').textContent=f.name;
 openModal('folderActionsModal');
}
$('folderActionEdit').onclick=()=>{
 if(!folderActionTarget)return;
 const id=folderActionTarget;closeModal('folderActionsModal');editFolder(id);
};
$('folderActionMove').onclick=()=>{
 if(!folderActionTarget)return;
 const id=folderActionTarget;closeModal('folderActionsModal');
 openMoveDialog('folder',id);
};
$('folderActionDelete').onclick=()=>{
 if(!folderActionTarget)return;
 editingFolder=folderActionTarget;closeModal('folderActionsModal');openModal('confirmModal');
};
function showCreateChoices(){openModal('createChoiceModal')}

$('createFolderChoice').onclick=()=>{closeModal('createChoiceModal');editFolder()};
$('createNoteChoice').onclick=()=>{closeModal('createChoiceModal');editNote()};
$('createPhotoChoice').onclick=()=>{closeModal('createChoiceModal');photoReplaceTarget=null;$('homePhotoInput').value='';$('homePhotoInput').click()};
$('createLayoutChoice').onclick=()=>{
 closeModal('createChoiceModal');
 if(layoutEditing){layoutEditing=false;persistHomeOrder();render();toast('Расположение сохранено')}
 else{layoutEditing=true;render();toast('Перемещай элементы и нажми «Готово»')}
};
$('cancelCreateChoice').onclick=()=>closeModal('createChoiceModal');

function editFolder(id=null){editingFolder=id;let f=id?db.folders.find(x=>x.id===id):null;$('folderModalTitle').textContent=f?'Настроить папку':'Новая папка';$('folderName').value=f?.name||'';selectedIcon=f?.icon||'📁';selectedColor=f?.color||colors[2];renderIconPicker();renderPalette();openModal('folderModal')}
function renderIconPicker(){$('iconTabs').innerHTML=Object.keys(iconGroups).map(t=>`<button class="tab ${t===activeIconTab?'active':''}" data-tab="${t}">${t}</button>`).join('');$('iconTabs').querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{activeIconTab=b.dataset.tab;renderIconPicker()});$('iconGrid').innerHTML=iconGroups[activeIconTab].map(i=>`<button class="icon-choice ${i===selectedIcon?'selected':''}" data-icon="${i}">${i}</button>`).join('');$('iconGrid').querySelectorAll('[data-icon]').forEach(b=>b.onclick=()=>{selectedIcon=b.dataset.icon;renderIconPicker()})}
function renderPalette(){
 $('palette').innerHTML=colors.map(c=>`<button type="button" class="swatch ${c.toLowerCase()===selectedColor.toLowerCase()?'selected':''}" style="background:${c}" data-color="${c}"></button>`).join('');
 $('palette').querySelectorAll('[data-color]').forEach(b=>b.onclick=()=>{selectedColor=b.dataset.color;renderPalette()});
 const saved=$('folderSavedColors');saved.innerHTML=(db.folderColors||[]).map((c,i)=>`<span class="saved-color-item"><button type="button" class="swatch ${c.toLowerCase()===selectedColor.toLowerCase()?'selected':''}" style="background:${c}" data-folder-saved-color="${c}" aria-label="Применить цвет"></button><button type="button" class="saved-color-remove" data-folder-color-remove="${i}" aria-label="Удалить сохранённый цвет">×</button></span>`).join('')||'<span class="saved-color-empty">Сохранённых цветов пока нет</span>';
 saved.querySelectorAll('[data-folder-saved-color]').forEach(b=>b.onclick=()=>{selectedColor=b.dataset.folderSavedColor;renderPalette()});
 saved.querySelectorAll('[data-folder-color-remove]').forEach(b=>b.onclick=()=>{db.folderColors.splice(Number(b.dataset.folderColorRemove),1);save();renderPalette()});
 $('folderCustomColorPreview').style.background=selectedColor;
}
$('saveFolder').onclick=()=>{let name=$('folderName').value.trim();if(!name){toast('Укажи название папки');return}if(editingFolder){let f=db.folders.find(x=>x.id===editingFolder);Object.assign(f,{name,icon:selectedIcon,color:selectedColor})}else db.folders.push({id:uid(),parentId:currentFolder,name,icon:selectedIcon,color:selectedColor,createdAt:Date.now()});save();closeModal('folderModal');render();toast('Папка сохранена')};
let editorAttachments=[];
let selectedEditorImage=null;
let autoSaveTimer=null;
let savedEditorRange=null;

function plainTextFromEditor(){
 return $('noteEditor').innerText.replace(/\u00a0/g,' ').trim();
}
function rememberEditorSelection(){
 const sel=window.getSelection();
 if(sel && sel.rangeCount && $('noteEditor').contains(sel.anchorNode)){
   savedEditorRange=sel.getRangeAt(0).cloneRange();
 }
}
function restoreEditorSelection(){
 const sel=window.getSelection();
 $('noteEditor').focus();
 if(savedEditorRange){
   sel.removeAllRanges();
   sel.addRange(savedEditorRange);
 }
}
function renderAttachments(){
 $('attachmentList').innerHTML=editorAttachments.map((a,i)=>`<div class="attachment-chip"><span>📎</span><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1">${esc(a.name)}</span><button type="button" data-remove-attachment="${i}">✕</button></div>`).join('');
 $('attachmentList').querySelectorAll('[data-remove-attachment]').forEach(b=>b.onclick=()=>{
   editorAttachments.splice(Number(b.dataset.removeAttachment),1);
   renderAttachments();scheduleAutoSave();
 });
}
function updateImageControls(){
 const slider=$('imageSize'), label=$('imageSizeValue'), controls=$('imageSizeControls');
 if(selectedEditorImage && selectedEditorImage.isConnected){
   controls.hidden=false;
   let w=parseInt(selectedEditorImage.style.width||'100%');
   slider.disabled=false;slider.value=Math.min(100,Math.max(20,w));label.textContent=slider.value+'%';
 } else {
   controls.hidden=true;slider.disabled=true;label.textContent='—';
 }
}
function scheduleAutoSave(){
 $('autosaveStatus').textContent='Сохранение…';
 clearTimeout(autoSaveTimer);
 autoSaveTimer=setTimeout(()=>persistNote(true),700);
}
let pendingNewNoteFolderId=undefined;
function persistNote(silent=false){
 const title=$('noteTitle').value.trim();
 const htmlBody=$('noteEditor').innerHTML.trim();
 const body=plainTextFromEditor();
 if(!title && !body && !editorAttachments.length && !db.notes.some(x=>x.id===editingNote&&x.hiddenPhotoNote))return;
 const now=Date.now();
 let n=editingNote?db.notes.find(x=>x.id===editingNote):null;
 if(!n){
   n={id:uid(),folderId:pendingNewNoteFolderId!==undefined?pendingNewNoteFolderId:currentFolder,title:title||'Без названия',body,bodyHtml:htmlBody,attachments:editorAttachments.slice(),color:selectedNoteColor||'',createdAt:now,updatedAt:now};
   db.notes.push(n);editingNote=n.id;pendingNewNoteFolderId=undefined;
 }else{
   if(!n.createdAt)n.createdAt=n.updatedAt||now;
   Object.assign(n,{title:title||'Без названия',body,bodyHtml:htmlBody,attachments:editorAttachments.slice(),color:selectedNoteColor||'',updatedAt:now});
 }
 try{
   save();
   $('autosaveStatus').textContent='Сохранено автоматически';
 }catch(e){
   $('autosaveStatus').textContent='Не удалось сохранить — возможно, недостаточно памяти';
   if(!silent)toast('Не удалось сохранить изменения');
 }
}
function editNote(id=null,targetFolderId=undefined){
 clearTimeout(autoSaveTimer);
 editingNote=id;
 pendingNewNoteFolderId=id?undefined:targetFolderId;
 let n=id?db.notes.find(x=>x.id===id):null;
 if(id && !n){toast('Не удалось найти заметку');return}
 $('noteModalTitle').textContent=n?'Редактировать заметку':'Новая заметка';
 $('noteTitle').value=n?.title||'';
 const linkedPhoto=n?.hiddenPhotoNote?db.photos.find(p=>p.id===n.photoId):null;
 const photoPreview=$('linkedPhotoEditorPreview');
 photoPreview.hidden=!linkedPhoto;
 photoPreview.innerHTML=linkedPhoto?`<img src="${linkedPhoto.data}" alt="${esc(linkedPhoto.name||'Фотография')}">`:'';
 selectedNoteColor=/^#[0-9a-fA-F]{6}$/.test(n?.color||'')?n.color:'';
 if(n?.bodyHtml){$('noteEditor').innerHTML=n.bodyHtml}
 else{$('noteEditor').innerHTML=esc(n?.body||'').replace(/\n/g,'<br>')}
 $('noteEditor').querySelectorAll('input[type=checkbox]').forEach(box=>{box.checked=box.hasAttribute('checked')});
 editorAttachments=Array.isArray(n?.attachments)?n.attachments.slice():[];
 savedEditorRange=null;selectedEditorImage=null;updateImageControls();renderAttachments();
 $('autosaveStatus').textContent='Автосохранение включено';
 closeModal('viewModal');openModal('noteModal');
}
function hslToHex(h,s,l){
 s/=100;l/=100;const k=n=>(n+h/30)%12;
 const a=s*Math.min(l,1-l);
 const f=n=>Math.round(255*(l-a*Math.max(-1,Math.min(k(n)-3,Math.min(9-k(n),1)))));
 return '#'+[f(0),f(8),f(4)].map(v=>v.toString(16).padStart(2,'0')).join('').toUpperCase();
}
function hexToRgb(hex){
 const x=parseInt(hex.slice(1),16);return {r:(x>>16)&255,g:(x>>8)&255,b:x&255};
}
function softNoteColor(hex){
 const {r,g,b}=hexToRgb(hex),mix=v=>Math.round(v*.20+255*.80);
 return `rgb(${mix(r)},${mix(g)},${mix(b)})`;
}
function currentPickerColor(){
 return hslToHex(Number($('noteHue').value),Number($('noteSaturation').value),Number($('noteLightness').value));
}
function updateNoteColorPreview(){
 const c=currentPickerColor();$('noteColorPreview').style.background=c;
 $('noteColorPreview').title=c;
}
let sharedColorTarget='note';
function getSharedColor(){
 if(sharedColorTarget==='folder')return selectedColor||'#399B68';
 if(sharedColorTarget==='event')return selectedEventColor&&selectedEventColor!=='none'?selectedEventColor:'#D69B45';
 return selectedNoteColor||'#B7DDBB';
}
function setSharedColor(value){
 if(sharedColorTarget==='folder')selectedColor=value;
 else if(sharedColorTarget==='event')selectedEventColor=value;
 else selectedNoteColor=value;
}
function getSharedColorList(){
 if(sharedColorTarget==='folder')return db.folderColors;
 if(sharedColorTarget==='event')return db.eventColors;
 return db.noteColors;
}
function renderNoteColorPalette(){
 const list=$('noteColorSwatches');if(!list)return;
 const colors=getSharedColorList()||[],current=getSharedColor();
 list.innerHTML=colors.map((c,i)=>`<button type="button" class="note-color-swatch ${c.toLowerCase()===current.toLowerCase()?'selected':''}" style="background:${c}" data-shared-color="${c}" aria-label="Применить цвет ${c}"><span class="swatch-remove" data-remove-shared-color="${i}">×</span></button>`).join('');
 list.querySelectorAll('[data-shared-color]').forEach(b=>b.onclick=e=>{
  if(e.target.closest('[data-remove-shared-color]'))return;
  setSharedColor(b.dataset.sharedColor);
  const v=hexToHsl(b.dataset.sharedColor);
  $('noteHue').value=v.h;$('noteSaturation').value=v.s;$('noteLightness').value=Math.max(15,Math.min(92,v.l));
  $('noteColorPreview').style.background=b.dataset.sharedColor;
  renderNoteColorPalette();
 });
 list.querySelectorAll('[data-remove-shared-color]').forEach(b=>b.onclick=e=>{
  e.stopPropagation();const i=Number(b.dataset.removeSharedColor);
  getSharedColorList().splice(i,1);
  save();renderNoteColorPalette();
 });
}
function openNoteColorPicker(target='note',initial=null){
 sharedColorTarget=target;
 const current=initial||getSharedColor();
 const v=hexToHsl(current);
 $('noteColorModal').querySelector('h3').textContent=target==='folder'?'Цвет папки':target==='event'?'Цвет напоминания':'Цвет заметки';
 $('clearNoteColor').textContent=target==='event'?'Без отметки':'Без цвета';
 $('noteHue').value=v.h;$('noteSaturation').value=v.s;$('noteLightness').value=Math.max(15,Math.min(92,v.l));
 updateNoteColorPreview();renderNoteColorPalette();openModal('noteColorModal');
}
['noteHue','noteSaturation','noteLightness'].forEach(id=>$(id).addEventListener('input',updateNoteColorPreview));
$('noteColorBtn').onclick=()=>openNoteColorPicker('note');
$('addNoteColor').onclick=()=>{
 const c=currentPickerColor(),list=getSharedColorList();
 if(!list.includes(c)){list.push(c);save()}
 setSharedColor(c);renderNoteColorPalette();updateNoteColorPreview();toast('Цвет добавлен в выбранные');
};
$('clearNoteColor').onclick=()=>{
 if(sharedColorTarget==='event')setSharedColor('none');
 else if(sharedColorTarget==='folder')setSharedColor(colors[2]);
 else setSharedColor('');
 if(sharedColorTarget==='folder')renderPalette();
 if(sharedColorTarget==='event')setEventColor('none');
 closeModal('noteColorModal');
 if(sharedColorTarget==='note')scheduleAutoSave();
};
$('applyNoteColor').onclick=()=>{
 setSharedColor(currentPickerColor());
 if(sharedColorTarget==='folder')renderPalette();
 if(sharedColorTarget==='event')setEventColor(selectedEventColor);
 closeModal('noteColorModal');
 if(sharedColorTarget==='note')scheduleAutoSave();
};
$('noteTitle').addEventListener('input',scheduleAutoSave);
function convertTypedMarkerToList(ordered,startNumber=1){
 const editor=$('noteEditor'),sel=window.getSelection();
 if(!sel || !sel.rangeCount)return;
 let node=sel.getRangeAt(0).startContainer;
 let block=node.nodeType===Node.TEXT_NODE?node.parentElement:node;
 block=block.closest('#noteEditor p,#noteEditor div');
 if(!block && (node===editor || editor.contains(node))){
   block=document.createElement('div');
   if(node===editor){while(editor.firstChild)block.appendChild(editor.firstChild);editor.appendChild(block);}
   else{node.parentNode.insertBefore(block,node);block.appendChild(node);}
 }
 if(!block || block.classList.contains('check-row'))return;
 const listTag=ordered?'OL':'UL',prev=block.previousElementSibling;
 let list=null;
 if(prev && prev.tagName===listTag)list=prev;
 else{
   list=document.createElement(listTag);
   if(ordered)list.setAttribute('start',String(Math.max(1,startNumber||1)));
   block.parentNode.insertBefore(list,block);
 }
 const li=document.createElement('li');
 while(block.firstChild)li.appendChild(block.firstChild);
 list.appendChild(li);block.remove();
 if(list.nextElementSibling && list.nextElementSibling.tagName===listTag){
   const following=list.nextElementSibling;
   while(following.firstChild)list.appendChild(following.firstChild);
   following.remove();
 }
 const r=document.createRange();r.selectNodeContents(li);r.collapse(false);
 sel.removeAllRanges();sel.addRange(r);savedEditorRange=r.cloneRange();
}
$('noteEditor').addEventListener('input',()=>{
 rememberEditorSelection();
 // Markdown-like shortcuts: "1. " starts an ordered list; "- " or "* " starts bullets.
 const sel=window.getSelection();
 if(sel && sel.rangeCount){
   const r=sel.getRangeAt(0), node=r.startContainer, offset=r.startOffset;
   if(node.nodeType===Node.TEXT_NODE && offset===node.textContent.length){
     const prefix=node.textContent.slice(0,offset);
     const match=prefix.match(/(^|\n)(\s*)(\d+\.|[-*])\s$/);
     if(match){
       const marker=match[0];
       node.deleteData(offset-marker.length,marker.length);
       const ordered=/\d+\.$/.test(match[3]);
       const startNumber=ordered?parseInt(match[3],10):1;
       convertTypedMarkerToList(ordered,startNumber);
       rememberEditorSelection();
     }
   }
 }
 scheduleAutoSave();
});
// Keep checkbox state in the editor HTML itself; innerHTML is what autosave persists.
$('noteEditor').addEventListener('change',e=>{
 const box=e.target;
 if(box&&box.matches('input[type=checkbox]')){
  if(box.checked)box.setAttribute('checked','checked');else box.removeAttribute('checked');
  scheduleAutoSave();
 }
},true);
$('noteEditor').addEventListener('click',e=>{
 const box=e.target;
 if(box&&box.matches('input[type=checkbox]'))setTimeout(()=>{if(box.checked)box.setAttribute('checked','checked');else box.removeAttribute('checked');scheduleAutoSave()},0);
});
$('noteEditor').addEventListener('keyup',rememberEditorSelection);
$('noteEditor').addEventListener('mouseup',rememberEditorSelection);
$('noteEditor').addEventListener('touchend',()=>setTimeout(rememberEditorSelection,0));
function keepNoteEditorAboveKeyboard(){
 const modal=$('noteModal');if(!modal)return;
 const vv=window.visualViewport;
 if(!vv)return;
 const visible=Math.max(240,Math.round(vv.height));
 modal.style.setProperty('--note-visible-height',visible+'px');
 const active=document.activeElement;
 const editing=modal.classList.contains('show')&&(active===$('noteEditor')||active===$('noteTitle')||active?.closest?.('#noteEditor'));
 modal.classList.toggle('keyboard-open',editing&&visible<window.innerHeight-80);
 if(editing){
  requestAnimationFrame(()=>{
   const target=active===$('noteTitle')?active:(window.getSelection()?.anchorNode?.parentElement?.closest?.('#noteEditor')?window.getSelection().anchorNode.parentElement:null);
   if(target&&target!==$('noteEditor'))target.scrollIntoView({block:'nearest',behavior:'smooth'});
   else if(active===$('noteEditor'))$('noteEditor').scrollTop=$('noteEditor').scrollHeight;
  });
 }
}
if(window.visualViewport){window.visualViewport.addEventListener('resize',keepNoteEditorAboveKeyboard);window.visualViewport.addEventListener('scroll',keepNoteEditorAboveKeyboard)}
document.addEventListener('focusin',e=>{if(e.target.closest?.('#noteModal'))setTimeout(keepNoteEditorAboveKeyboard,80)});
document.addEventListener('focusout',e=>{if(e.target.closest?.('#noteModal'))setTimeout(keepNoteEditorAboveKeyboard,120)});

$('noteEditor').addEventListener('click',e=>{
 if(e.target.tagName==='IMG'){
   if(selectedEditorImage)selectedEditorImage.classList.remove('selected-image');
   selectedEditorImage=e.target;selectedEditorImage.classList.add('selected-image');
   updateImageControls();
 }else if(selectedEditorImage){
   selectedEditorImage.classList.remove('selected-image');selectedEditorImage=null;updateImageControls();
 }
 rememberEditorSelection();
});
$('imageSize').oninput=e=>{
 if(selectedEditorImage){
   selectedEditorImage.style.width=e.target.value+'%';
   selectedEditorImage.style.height='auto';
   $('imageSizeValue').textContent=e.target.value+'%';
   scheduleAutoSave();
 }
};
document.querySelectorAll('#editorToolbar [data-cmd]').forEach(b=>{
 b.addEventListener('mousedown',e=>e.preventDefault());
 b.onclick=()=>{
   restoreEditorSelection();
   document.execCommand(b.dataset.cmd,false,null);
   rememberEditorSelection();scheduleAutoSave();
 };
});
function currentEditorBlock(){
 const sel=window.getSelection();
 if(!sel || !sel.rangeCount)return null;
 let el=sel.getRangeAt(0).startContainer;
 if(el.nodeType===Node.TEXT_NODE)el=el.parentElement;
 return el && el.closest('#noteEditor p,#noteEditor h1,#noteEditor h2,#noteEditor h3,#noteEditor div,#noteEditor li');
}
function applyBlockFormat(tag){
 restoreEditorSelection();
 const block=currentEditorBlock();
 if(!block){scheduleAutoSave();return}
 // Keep list item semantics intact so numbering never restarts at every row.
 if(block.tagName==='LI'){
   if(tag==='h2'){block.style.fontSize='1.35em';block.style.fontWeight='700'}
   else if(tag==='h3'){block.style.fontSize='1.15em';block.style.fontWeight='650'}
   else{block.style.fontSize='';block.style.fontWeight=''}
 }else{
   const target=tag==='p'?'p':tag;
   if(block.tagName.toLowerCase()!==target){
     const replacement=document.createElement(target);
     while(block.firstChild)replacement.appendChild(block.firstChild);
     block.replaceWith(replacement);
     const sel=window.getSelection(),r=document.createRange();
     r.selectNodeContents(replacement);r.collapse(false);
     sel.removeAllRanges();sel.addRange(r);
   }
 }
 rememberEditorSelection();scheduleAutoSave();
}
$('blockFormat').onchange=e=>applyBlockFormat(e.target.value);
function makeChecklistRow(){
 const row=document.createElement('div');row.className='check-row';
 const box=document.createElement('input');box.type='checkbox';box.setAttribute('contenteditable','false');
 const text=document.createElement('span');text.className='check-text';text.setAttribute('contenteditable','true');
 row.append(box,text);
 return row;
}
function focusChecklistText(text){
 const sel=window.getSelection(),range=document.createRange();
 range.selectNodeContents(text);range.collapse(false);
 sel.removeAllRanges();sel.addRange(range);
 $('noteEditor').focus();rememberEditorSelection();
}
$('checklistBtn').onclick=()=>{
 const editor=$('noteEditor');restoreEditorSelection();
 const sel=window.getSelection();
 let current=sel&&sel.rangeCount?sel.getRangeAt(0).startContainer:null;
 let node=current&&current.nodeType===Node.TEXT_NODE?current.parentElement:current;
 const currentRow=node&&node.closest?node.closest('.check-row'):null;
 const row=makeChecklistRow();
 if(currentRow&&editor.contains(currentRow)){
   currentRow.insertAdjacentElement('afterend',row);
 }else{
   const range=sel&&sel.rangeCount?sel.getRangeAt(0):null;
   if(range&&editor.contains(range.startContainer)){
     range.deleteContents();range.insertNode(row);
   }else editor.append(row);
 }
 focusChecklistText(row.querySelector('.check-text'));scheduleAutoSave();
};
// Enter creates the next checkbox row; Shift+Enter adds a line within the same item.
$('noteEditor').addEventListener('keydown',e=>{
 if(e.key!=='Enter')return;
 const sel=window.getSelection();if(!sel||!sel.rangeCount)return;
 let node=sel.getRangeAt(0).startContainer;
 if(node.nodeType===Node.TEXT_NODE)node=node.parentElement;
 const text=node&&node.closest?node.closest('.check-text'):null;
 if(!text||!$('noteEditor').contains(text))return;
 e.preventDefault();
 if(e.shiftKey){
   document.execCommand('insertLineBreak',false,null);
   rememberEditorSelection();scheduleAutoSave();return;
 }
 const row=text.closest('.check-row'),next=makeChecklistRow();
 row.insertAdjacentElement('afterend',next);
 focusChecklistText(next.querySelector('.check-text'));scheduleAutoSave();
});
function insertImageFile(file){
 if(!file)return;
 if(!file.type.startsWith('image/')){toast('Это не изображение');return}
 if(file.size>15*1024*1024){toast('Фото слишком большое (максимум 15 МБ)');return}
 const reader=new FileReader();
 reader.onload=()=>{
   const source=reader.result,image=new Image();
   image.onload=()=>{
     const maxSide=1800,scale=Math.min(1,maxSide/Math.max(image.naturalWidth,image.naturalHeight));
     const canvas=document.createElement('canvas');
     canvas.width=Math.max(1,Math.round(image.naturalWidth*scale));
     canvas.height=Math.max(1,Math.round(image.naturalHeight*scale));
     canvas.getContext('2d').drawImage(image,0,0,canvas.width,canvas.height);
     const dataUrl=file.type==='image/png'?canvas.toDataURL('image/png'):canvas.toDataURL('image/jpeg',0.84);
     const editor=$('noteEditor');editor.focus();
     const img=document.createElement('img');img.src=dataUrl;img.alt=file.name;img.style.width='100%';
     let range=null;const sel=window.getSelection();
     if(savedEditorRange && editor.contains(savedEditorRange.startContainer))range=savedEditorRange.cloneRange();
     else if(sel && sel.rangeCount && editor.contains(sel.anchorNode))range=sel.getRangeAt(0).cloneRange();
     if(range){
       range.deleteContents();range.insertNode(img);
       const after=document.createElement('div');after.appendChild(document.createElement('br'));img.after(after);
       const nextRange=document.createRange();nextRange.setStart(after,0);nextRange.collapse(true);
       if(sel){sel.removeAllRanges();sel.addRange(nextRange)}savedEditorRange=nextRange.cloneRange();
     }else{
       editor.appendChild(img);
       const after=document.createElement('div');after.appendChild(document.createElement('br'));editor.appendChild(after);
       const nextRange=document.createRange();nextRange.setStart(after,0);nextRange.collapse(true);
       if(sel){sel.removeAllRanges();sel.addRange(nextRange)}savedEditorRange=nextRange.cloneRange();
     }
     if(selectedEditorImage)selectedEditorImage.classList.remove('selected-image');
     selectedEditorImage=img;img.classList.add('selected-image');
     updateImageControls();scheduleAutoSave();toast('Фотография вставлена в текст');
   };
   image.onerror=()=>toast('Не удалось обработать фотографию');image.src=source;
 };
 reader.onerror=()=>toast('Не удалось прочитать фотографию');reader.readAsDataURL(file);
}
$('imageBtn').onclick=()=>{
 rememberEditorSelection();
 $('imageInput').click();
};
$('imageInput').onchange=e=>{
 const file=e.target.files && e.target.files[0];
 e.target.value='';
 insertImageFile(file);
};
$('attachBtn').onclick=()=>{
 rememberEditorSelection();
 $('fileInput').click();
};
$('fileInput').onchange=e=>{
 const files=Array.from(e.target.files||[]);e.target.value='';
 files.forEach(file=>{
   // Images are always embedded inline, even if selected through the generic
   // Android file picker. Only non-image documents become attachment chips.
   if(file.type.startsWith('image/')){
     insertImageFile(file);
     return;
   }
   if(file.size>1200000){toast('Файл '+file.name+' слишком большой для этой версии');return}
   const reader=new FileReader();
   reader.onload=()=>{editorAttachments.push({name:file.name,type:file.type,data:reader.result,size:file.size});renderAttachments();scheduleAutoSave()};
   reader.readAsDataURL(file);
 });
};
$('saveNote').onclick=()=>{
 const title=$('noteTitle').value.trim(),body=plainTextFromEditor();
 if(!title&&!body&&!editorAttachments.length){toast('Добавь текст или файл');return}
 clearTimeout(autoSaveTimer);
 persistNote(false);
 closeModal('noteModal');render();toast('Заметка сохранена');
};
let moveTarget=null;
function openMoveDialog(type,id){
 moveTarget={type,id};
 const isFolder=type==='folder';
 const item=isFolder?db.folders.find(x=>x.id===id):db.notes.find(x=>x.id===id);
 if(!item)return;
 $('moveModalTitle').textContent=isFolder?'Переместить папку':'Переместить заметку';
 $('moveModalHint').textContent=isFolder?'Выбери новое место для папки. Все её заметки и вложенные папки переместятся вместе с ней.':'Выбери папку, в которой должна находиться эта заметка.';
 const oldPath=isFolder?folderPath(item.parentId):folderPath(item.folderId);
 $('moveCurrent').innerHTML=`Сейчас находится: <b>${oldPath.length?'Главная › '+oldPath.map(x=>esc(x.name)).join(' › '):'Главная'}</b>`;
 const excluded=isFolder?new Set([id,...descendants(id)]):new Set();
 const options=[{value:'__root__',label:'Главная',depth:0,parentId:null,icon:'⌂',color:null,hasChildren:false}];
 function addChildren(parent,depth){
   db.folders.filter(f=>f.parentId===parent&&!f.deletedAt&&!excluded.has(f.id)).sort((a,b)=>a.name.localeCompare(b.name,'ru')).forEach(f=>{
     const hasChildren=db.folders.some(x=>x.parentId===f.id&&!x.deletedAt&&!excluded.has(x.id));
     options.push({value:f.id,label:f.name,depth,parentId:parent,icon:f.icon||'📁',color:f.color||null,hasChildren});
     addChildren(f.id,depth+1);
   });
 }
 addChildren(null,1);
 moveDestinationOptions=options;
 selectedMoveDestination='__root__';
 if(isFolder && item.parentId && !excluded.has(item.parentId))selectedMoveDestination=item.parentId;
 if(!isFolder && item.folderId && !excluded.has(item.folderId))selectedMoveDestination=item.folderId;
 moveExpandedFolders=new Set();
 let selectedItem=moveDestinationOptions.find(o=>o.value===selectedMoveDestination);
 while(selectedItem&&selectedItem.parentId){moveExpandedFolders.add(selectedItem.parentId);selectedItem=moveDestinationOptions.find(o=>o.value===selectedItem.parentId)}
 renderMoveDestinationList();
 openModal('moveModal');
}
let moveDestinationOptions=[],selectedMoveDestination='__root__',moveExpandedFolders=new Set();
function renderMoveDestinationList(){
 const byId=new Map(moveDestinationOptions.map(o=>[o.value,o]));
 const visible=moveDestinationOptions.filter(o=>{
  let parent=o.parentId;
  while(parent){if(!moveExpandedFolders.has(parent))return false;parent=byId.get(parent)?.parentId||null}
  return true;
 });
 $('moveDestinationList').innerHTML=visible.map(o=>`
 <div class="move-destination-option ${o.value===selectedMoveDestination?'selected':''}" data-move-destination="${esc(o.value)}" role="option" aria-selected="${o.value===selectedMoveDestination}" style="padding-left:${9+Math.max(0,o.depth-1)*17}px">
  <button type="button" class="move-tree-toggle" data-move-toggle="${esc(o.value)}" ${o.hasChildren?'':'disabled'} aria-label="${moveExpandedFolders.has(o.value)?'Свернуть':'Раскрыть'} папку">${o.hasChildren?(moveExpandedFolders.has(o.value)?'▾':'▸'):''}</button>
  <span class="move-folder-icon" style="${o.color?`background:${o.color}22;color:${o.color}`:''}">${esc(o.icon)}</span>
  <span class="move-folder-name" data-move-name="${esc(o.value)}">${esc(o.label)}</span>
 </div>`).join('');
 $('moveDestinationList').querySelectorAll('[data-move-destination]').forEach(row=>row.onclick=()=>{
  selectedMoveDestination=row.dataset.moveDestination;renderMoveDestinationList();
 });
 const toggleMoveFolder=id=>{
  if(moveExpandedFolders.has(id))moveExpandedFolders.delete(id);else moveExpandedFolders.add(id);
  renderMoveDestinationList();
 };
 $('moveDestinationList').querySelectorAll('[data-move-toggle]').forEach(btn=>btn.onclick=e=>{
  e.stopPropagation();toggleMoveFolder(btn.dataset.moveToggle);
 });
 $('moveDestinationList').querySelectorAll('[data-move-name]').forEach(name=>name.onclick=e=>{
  e.stopPropagation();const option=moveDestinationOptions.find(o=>o.value===name.dataset.moveName);
  if(option?.hasChildren)toggleMoveFolder(option.value);
  else {selectedMoveDestination=option.value;renderMoveDestinationList();}
 });
}
$('confirmMove').onclick=()=>{
 if(!moveTarget)return;
 const destination=selectedMoveDestination==='__root__'?null:selectedMoveDestination;
 if(moveTarget.type==='folder'){
   const f=db.folders.find(x=>x.id===moveTarget.id);
   if(destination===f.id || (destination && descendants(f.id).includes(destination))){toast('Нельзя переместить папку внутрь самой себя');return}
   f.parentId=destination;
 }else{
   const n=db.notes.find(x=>x.id===moveTarget.id);if(!n)return;
   const oldFolder=n.folderId??null;
   n.folderId=destination;
   if(n.hiddenPhotoNote){
    const ph=db.photos.find(x=>x.id===n.photoId);
    if(ph){
     ph.parentId=destination;
     const oldKey=oldFolder||'root',newKey=destination||'root';
     if(oldKey!==newKey){
      db.homeOrder[oldKey]=(db.homeOrder[oldKey]||[]).filter(x=>x!=='photo:'+ph.id);
      db.homeOrder[newKey]=db.homeOrder[newKey]||[];
      if(!db.homeOrder[newKey].includes('photo:'+ph.id))db.homeOrder[newKey].push('photo:'+ph.id);
     }
    }
   }
 }
 save();closeModal('moveModal');closeModal('viewModal');moveTarget=null;render();toast('Перемещено');
};
function viewNote(id){
 viewingNote=id;let n=db.notes.find(x=>x.id===id);if(!n)return;
 const linkedPhoto=n.hiddenPhotoNote?db.photos.find(p=>p.id===n.photoId):null;
 $('viewTitle').textContent=n.title||linkedPhoto?.name||'Без названия';
 $('viewDates').innerHTML=`<div>Создана: <strong style="color:#555;font-weight:600">${formatDate(n.createdAt||n.updatedAt)}</strong></div><div>Изменена: <strong style="color:#555;font-weight:600">${formatDate(n.updatedAt||n.createdAt)}</strong></div>`;
 if(linkedPhoto){
  const photoHtml=`<img src="${linkedPhoto.data}" alt="${esc(linkedPhoto.name||'Фотография')}" style="display:block;width:100%;height:auto;max-height:none;object-fit:contain;border-radius:14px">`;
  const textHtml=n.bodyHtml||(n.body?`<div>${esc(n.body).replace(/\n/g,'<br>')}</div>`:'');
  $('viewBody').innerHTML=photoHtml+(textHtml?`<div style="margin-top:12px;line-height:1.65;color:#555">${textHtml}</div>`:'');
 }else if(n.bodyHtml)$('viewBody').innerHTML=n.bodyHtml;else $('viewBody').textContent=n.body||'Пустая заметка';
 $('viewAttachments').innerHTML=(n.attachments||[]).map(a=>`<a href="${a.data}" download="${esc(a.name)}">📎 ${esc(a.name)} · Скачать</a>`).join('');
 $('viewBody').querySelectorAll('input[type="checkbox"]').forEach(box=>{box.disabled=true;box.tabIndex=-1;});
 $('viewScroll').scrollTop=0;
 openModal('viewModal');
}
$('closeView').onclick=()=>closeModal('viewModal');
// Close the note preview when the user taps the dimmed area outside the card.
$('viewModal').addEventListener('click',e=>{
 if(e.target===$('viewModal')) closeModal('viewModal');
});
$('editNote').onclick=()=>editNote(viewingNote);
$('moveNote').onclick=()=>openMoveDialog('note',viewingNote);
$('deleteNote').onclick=()=>openModal('deleteNoteConfirmModal');
$('confirmDeleteNote').onclick=()=>{
 const n=db.notes.find(x=>x.id===viewingNote);
 if(!n)return;
 if(n.hiddenPhotoNote){
  const photoId=n.photoId;
  db.photos=db.photos.filter(p=>p.id!==photoId);
  db.notes=db.notes.filter(x=>x.id!==n.id);
  db.homeOrder=Object.fromEntries(Object.entries(db.homeOrder).map(([k,v])=>[k,(v||[]).filter(x=>x!=='photo:'+photoId)]));
  save();closeModal('deleteNoteConfirmModal');closeModal('viewModal');render();toast('Фотография удалена');return;
 }
 n.deletedAt=Date.now();db.trash.push({type:'note',id:n.id,deletedAt:n.deletedAt});
 save();closeModal('deleteNoteConfirmModal');closeModal('viewModal');render();toast('Перемещено в корзину');
};
function descendants(id){let ids=[id];db.folders.filter(f=>f.parentId===id).forEach(f=>ids.push(...descendants(f.id)));return ids}
$('moveContents').onclick=()=>{let f=db.folders.find(x=>x.id===editingFolder);db.folders.filter(x=>x.parentId===editingFolder).forEach(x=>x.parentId=f.parentId);db.notes.filter(x=>x.folderId===editingFolder).forEach(x=>x.folderId=f.parentId);f.deletedAt=Date.now();db.trash.push({type:'folder',id:f.id,deletedAt:f.deletedAt});save();closeModal('confirmModal');render();toast('Содержимое перенесено')};
$('deleteContents').onclick=()=>{let ids=descendants(editingFolder),now=Date.now();ids.forEach(id=>{let f=db.folders.find(x=>x.id===id);if(f)f.deletedAt=now;db.trash.push({type:'folder',id,deletedAt:now})});db.notes.filter(n=>ids.includes(n.folderId)).forEach(n=>{n.deletedAt=now;db.trash.push({type:'note',id:n.id,deletedAt:now})});save();closeModal('confirmModal');if(ids.includes(currentFolder))currentFolder=null;render();toast('Перемещено в корзину')};
function renderTrash(){let items=db.trash.filter(t=>Date.now()-t.deletedAt<30*86400000);$('trashItems').innerHTML=items.map(t=>{let o=t.type==='note'?db.notes.find(x=>x.id===t.id):db.folders.find(x=>x.id===t.id);return o?`<div class="note"><span>${t.type==='note'?'▤':'📁'}</span><span style="flex:1">${esc(o.title||o.name)}</span><button class="small-action" data-restore="${t.type}:${t.id}">Восстановить</button></div>`:''}).join('')||'<div class="empty">Корзина пуста</div>';$('trashItems').querySelectorAll('[data-restore]').forEach(b=>b.onclick=()=>{let [type,id]=b.dataset.restore.split(':');let o=(type==='note'?db.notes:db.folders).find(x=>x.id===id);if(o){delete o.deletedAt;db.trash=db.trash.filter(t=>!(t.type===type&&t.id===id));save();renderTrash();render();toast('Восстановлено')}})}
$('emptyTrash').onclick=()=>{if(!confirm('Удалить содержимое корзины окончательно?'))return;let ids=db.trash;db.notes=db.notes.filter(n=>!ids.some(t=>t.type==='note'&&t.id===n.id));db.folders=db.folders.filter(f=>!ids.some(t=>t.type==='folder'&&t.id===f.id));db.trash=[];save();renderTrash();render();toast('Корзина очищена')};
let calendarCursor=new Date();calendarCursor.setDate(1);
let calendarSelected=new Date();
function setBottomTab(tab){
 const music=tab==='music',calendar=tab==='calendar';
 $('musicScreen').classList.toggle('visible',music);
 $('calendarScreen').classList.toggle('visible',calendar);
 $('fab').style.display=(music||calendar)?'none':'';
 $('homeNav').classList.toggle('active',tab==='home');
 $('musicNav').classList.toggle('active',music);
 $('calendarNav').classList.toggle('active',calendar);
}
function dayKey(d){return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
function updateCalendarNavDate(){
 const now=new Date();
 $('calendarNavDay').textContent=String(now.getDate());
 $('calendarNavMonth').textContent=now.toLocaleDateString('ru-RU',{month:'short'}).replace('.','').toUpperCase();
}
updateCalendarNavDate();
document.addEventListener('visibilitychange',()=>{if(!document.hidden)updateCalendarNavDate()});
window.addEventListener('focus',updateCalendarNavDate);

// Android native notifications and best-effort calendar reminders.
// The HTML bridge can display notifications, but cannot register persistent OS alarms.
function showNativeNotification(title,message,eventId){
 try{
  if(window.AndroidAPI&&typeof window.AndroidAPI.showNotification==='function'){
   window.AndroidAPI.showNotification(String(title||'Шкафчик'),String(message||''),String(eventId||''));
   return true;
  }
 }catch(err){console.warn('Android notification error',err)}
 return false;
}
window.addEventListener('notificationResult',function(event){
 const result=event.detail||{};
 const status=$('notificationStatus');
 if(status){
  if(result.success)status.textContent='Android успешно принял уведомление.';
  else if(result.error==='permission_denied')status.textContent='Android запретил уведомления. Проверь разрешение в настройках телефона.';
  else status.textContent='Не удалось отправить уведомление: '+(result.error||'неизвестная ошибка');
 }
});
$('exactAlarmBtn').onclick=()=>{
 if(window.AndroidAPI&&typeof window.AndroidAPI.requestExactAlarmAccess==='function'){
  window.AndroidAPI.requestExactAlarmAccess();
  $('notificationStatus').textContent='Открыл настройки точных будильников Android. Разреши доступ и вернись в приложение.';
 }else $('notificationStatus').textContent='Функция доступна только в установленном Android-приложении.';
};
$('notificationSettingsBtn').onclick=()=>{
 if(window.AndroidAPI&&typeof window.AndroidAPI.requestNotificationPermission==='function'){
  window.AndroidAPI.requestNotificationPermission();
  $('notificationStatus').textContent='Проверь разрешение на уведомления в Android.';
 }else $('notificationStatus').textContent='Открой настройки уведомлений Android для приложения.';
};
window.exactAlarmPermissionResult=function(granted){
 const s=$('notificationStatus');
 if(s)s.textContent=granted?'Точные будильники разрешены. Расписание обновлено.':'Точные будильники пока не разрешены. Напоминания могут приходить с задержкой.';
};
window.notificationPermissionResult=function(granted){
 const s=$('notificationStatus');
 if(s)s.textContent=granted?'Уведомления разрешены.':'Уведомления запрещены Android. Разреши их в настройках приложения.';
};
$('testNotificationBtn').onclick=()=>{
 const ok=showNativeNotification('Шкафчик','Уведомления работают. Можно настраивать напоминания о событиях.');
 $('notificationStatus').textContent=ok?'Запрос отправлен Android. Подожди несколько секунд.':'Android API не найден. Открой APK, собранный конструктором с включёнными уведомлениями.';
};
function scanCalendarReminders(){
 if(!Array.isArray(db.events)||!db.events.length)return;
 const now=new Date(),today=new Date(now.getFullYear(),now.getMonth(),now.getDate(),12);
 const sent=Array.isArray(db.notificationSent)?db.notificationSent:[];
 let changed=false;
 for(let offset=0;offset<=1;offset++){
  const day=new Date(today.getFullYear(),today.getMonth(),today.getDate()+offset,12);
  const keyDate=dayKey(day);
  for(const ev of db.events){
   if(!eventOccursOn(ev,day))continue;
   const parts=(ev.time||'09:00').split(':').map(Number);
   const eventAt=new Date(day.getFullYear(),day.getMonth(),day.getDate(),parts[0]||0,parts[1]||0);
   const remindAt=new Date(eventAt.getTime()-(Number(ev.reminder)||0)*60000);
   const dedupe=String(ev.id)+'|'+keyDate;
   if(sent.includes(dedupe))continue;
   // Send only near the reminder moment; do not fire stale reminders after an event.
   if(now>=remindAt && now<=new Date(eventAt.getTime()+5*60000)){
    const message=[ev.description||'', 'Время: '+(ev.time||'09:00')].filter(Boolean).join('\n');
    if(showNativeNotification(ev.title||'Напоминание',message,ev.id)){
     sent.push(dedupe);changed=true;
    }
   }
  }
 }
 if(changed){db.notificationSent=sent.slice(-500);save();}
}
let reminderScanTimer=null;
function startReminderScanner(){
 if(reminderScanTimer)clearInterval(reminderScanTimer);
 // В Android расписанием управляет системный AlarmManager; JS-проверка остаётся
 // только для запуска приложения в браузере и не дублирует системные уведомления.
 if(window.AndroidAPI&&typeof window.AndroidAPI.syncReminders==='function')return;
 scanCalendarReminders();
 reminderScanTimer=setInterval(scanCalendarReminders,15000);
}
document.addEventListener('visibilitychange',()=>{if(!document.hidden)scanCalendarReminders()});
window.addEventListener('focus',scanCalendarReminders);

function eventOccursOn(ev,date){
 const base=new Date(ev.date+'T12:00:00'), target=new Date(date.getFullYear(),date.getMonth(),date.getDate(),12);
 if(target<new Date(base.getFullYear(),base.getMonth(),base.getDate(),12))return false;
 const diff=Math.round((target-base)/86400000);
 if(ev.repeat==='daily')return true;
 if(ev.repeat==='weekly')return diff%7===0;
 if(ev.repeat==='monthly')return target.getDate()===base.getDate();
 if(ev.repeat==='yearly')return target.getDate()===base.getDate()&&target.getMonth()===base.getMonth();
 return diff===0;
}
function renderCalendar(){
 const y=calendarCursor.getFullYear(),m=calendarCursor.getMonth();
 $('calendarMonth').textContent=calendarCursor.toLocaleDateString('ru-RU',{month:'long',year:'numeric'});
 const first=new Date(y,m,1),offset=(first.getDay()+6)%7,start=new Date(y,m,1-offset);
 const today=dayKey(new Date()),selected=dayKey(calendarSelected);
 const dates=Array.from({length:42},(_,i)=>new Date(start.getFullYear(),start.getMonth(),start.getDate()+i));
 $('calendarDays').innerHTML=dates.map(d=>{
   const key=dayKey(d),dayNotes=db.notes.filter(n=>!n.deletedAt&&!n.hiddenPhotoNote&&[n.createdAt,n.updatedAt].some(t=>t&&dayKey(new Date(t))===key));
   const dayEvents=db.events.filter(ev=>eventOccursOn(ev,d));
   const visibleEventMarkers=dayEvents.filter(ev=>ev.color!=='none').slice(0,10);
   const visibleNoteMarkers=dayNotes.slice(0,10);
   const eventMarkers=visibleEventMarkers.map(ev=>`<i class="calendar-marker-event" style="background:${/^#[0-9a-f]{6}$/i.test(ev.color||'')?ev.color:'#D69B45'}"></i>`).join('');
   const noteMarkers=visibleNoteMarkers.map(()=>'<i class="calendar-marker-note"></i>').join('');
   const markers=`<span class="calendar-markers"><span class="calendar-marker-row">${eventMarkers}</span><span class="calendar-marker-row">${noteMarkers}</span></span>`;
   return `<button class="calendar-day ${d.getMonth()!==m?'muted':''} ${key===today?'today':''} ${key===selected?'selected':''}" data-day="${key}">${d.getDate()}${markers}</button>`;
 }).join('');
 $('calendarDays').querySelectorAll('[data-day]').forEach(b=>b.onclick=()=>{
   const [yy,mm,dd]=b.dataset.day.split('-').map(Number);calendarSelected=new Date(yy,mm-1,dd);calendarCursor=new Date(yy,mm-1,1);renderCalendar();
 });
 const key=dayKey(calendarSelected);
 const matches=db.notes.filter(n=>!n.deletedAt&&!n.hiddenPhotoNote&&[n.createdAt,n.updatedAt].some(t=>t&&dayKey(new Date(t))===key));
 const dayEvents=db.events.filter(ev=>eventOccursOn(ev,calendarSelected)).sort((a,b)=>(a.time||'').localeCompare(b.time||''));
 $('calendarDayNotes').innerHTML=`<div class="calendar-day-title">${calendarSelected.toLocaleDateString('ru-RU',{day:'numeric',month:'long',year:'numeric'})}</div>`+
 (dayEvents.length?dayEvents.map(ev=>`<button class="calendar-event" data-calendar-event="${ev.id}"><i class="event-dot" style="--event-color:${ev.color==="none"?"transparent":(/^#[0-9a-f]{6}$/i.test(ev.color||"")?ev.color:"#D69B45")}"></i><span class="event-main"><strong>${esc(ev.title)}</strong><small>${esc(ev.time||'Весь день')}${ev.repeat&&ev.repeat!=='none'?' · '+({daily:'ежедневно',weekly:'еженедельно',monthly:'ежемесячно',yearly:'ежегодно'}[ev.repeat]):''}</small></span></button>`).join(''):'')+
 (matches.length?matches.map(n=>`<button class="calendar-note" data-calendar-note="${n.id}"><span>📝 ${esc(n.title||'Без названия')}</span><small>${n.updatedAt&&dayKey(new Date(n.updatedAt))===key?'Изменена':'Создана'}</small></button>`).join(''):'')+
 (!dayEvents.length&&!matches.length?'<div class="empty">На эту дату заметок и событий нет</div>':'');
 $('calendarDayNotes').querySelectorAll('[data-calendar-note]').forEach(b=>b.onclick=()=>viewNote(b.dataset.calendarNote));
 $('calendarDayNotes').querySelectorAll('[data-calendar-event]').forEach(b=>{
  let pressTimer=null,didLongPress=false,pressX=0,pressY=0;
  const cancelEventPress=()=>{if(pressTimer){clearTimeout(pressTimer);pressTimer=null;}};
  b.style.webkitUserSelect='none';b.style.userSelect='none';b.style.touchAction='pan-y';
  b.addEventListener('pointerdown',e=>{
   if(e.pointerType!=='touch'&&e.pointerType!=='pen')return;
   cancelEventPress();didLongPress=false;pressX=e.clientX;pressY=e.clientY;
   pressTimer=setTimeout(()=>{didLongPress=true;pressTimer=null;openCalendarEventActions(b.dataset.calendarEvent);},550);
  });
  b.addEventListener('pointermove',e=>{if(pressTimer&&(Math.abs(e.clientX-pressX)>12||Math.abs(e.clientY-pressY)>12))cancelEventPress();});
  b.addEventListener('pointerup',cancelEventPress);
  b.addEventListener('pointercancel',cancelEventPress);
  b.addEventListener('contextmenu',e=>{e.preventDefault();cancelEventPress();didLongPress=true;openCalendarEventActions(b.dataset.calendarEvent);});
  b.addEventListener('click',e=>{if(didLongPress){e.preventDefault();e.stopImmediatePropagation();didLongPress=false;return;}editCalendarEvent(b.dataset.calendarEvent);},true);
 });
}
let calendarActionEventId=null;
function openCalendarEventActions(id){
 const ev=(db.events||[]).find(x=>String(x.id)===String(id));
 if(!ev)return;
 calendarActionEventId=ev.id;
 let wrap=$('calendarEventActions');
 if(!wrap){
  wrap=document.createElement('div');wrap.className='modal-wrap';wrap.id='calendarEventActions';
  wrap.innerHTML=`<div class="modal"><h3 id="calendarEventActionsTitle"></h3><p style="color:var(--muted);margin:0 0 16px">Что сделать с этим напоминанием?</p><div class="actions" style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><button type="button" class="secondary" id="calendarEventEditAction">Редактировать</button><button type="button" class="danger" id="calendarEventDeleteAction">Удалить</button></div><div class="actions"><button type="button" class="secondary" id="calendarEventCancelAction">Отмена</button></div></div>`;
  document.body.appendChild(wrap);
  $('calendarEventCancelAction').onclick=()=>closeModal('calendarEventActions');
  $('calendarEventEditAction').onclick=()=>{const selected=calendarActionEventId;closeModal('calendarEventActions');editCalendarEvent(selected);};
  $('calendarEventDeleteAction').onclick=()=>{
   const selected=calendarActionEventId;
   const item=(db.events||[]).find(x=>String(x.id)===String(selected));
   if(!item)return;
   if(!confirm('Удалить напоминание «'+(item.title||'Без названия')+'»?'))return;
   db.events=db.events.filter(x=>String(x.id)!==String(selected));
   save();closeModal('calendarEventActions');renderCalendar();toast('Напоминание удалено');
  };
  wrap.addEventListener('click',e=>{if(e.target===wrap)closeModal('calendarEventActions');});
 }
 $('calendarEventActionsTitle').textContent=ev.title||'Без названия';
 openModal('calendarEventActions');
}
let editingCalendarEvent=null;
let selectedEventColor='#D69B45';
function setEventColor(color){
 selectedEventColor=color;
 $('eventColorPicker').querySelectorAll('[data-event-color]').forEach(b=>b.classList.toggle('selected',b.dataset.eventColor===color));
 if(typeof renderEventSavedColors==='function')renderEventSavedColors();
}
$('eventColorPicker').querySelectorAll('[data-event-color]').forEach(b=>b.onclick=()=>setEventColor(b.dataset.eventColor));
function renderEventSavedColors(){
 const box=$('eventSavedColors');if(!box)return;
 box.innerHTML=(db.eventColors||[]).map((c,i)=>`<span class="saved-color-item"><button type="button" class="event-color-swatch ${selectedEventColor===c?'selected':''}" style="--swatch:${c}" data-event-saved-color="${c}" aria-label="Применить цвет"></button><button type="button" class="saved-color-remove" data-event-color-remove="${i}" aria-label="Удалить сохранённый цвет">×</button></span>`).join('')||'<span class="saved-color-empty">Сохранённых цветов пока нет</span>';
 box.querySelectorAll('[data-event-saved-color]').forEach(b=>b.onclick=()=>{setEventColor(b.dataset.eventSavedColor);renderEventSavedColors()});
 box.querySelectorAll('[data-event-color-remove]').forEach(b=>b.onclick=()=>{db.eventColors.splice(Number(b.dataset.eventColorRemove),1);save();renderEventSavedColors()});
}
renderEventSavedColors();


function currentClockValue(){
 const d=new Date();
 return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');
}
let timeWheelValue={hour:0,minute:0};
function buildTimeWheel(id,max,value){
 const el=$(id);
 const items=['<div class="time-wheel-spacer"></div>'];
 for(let i=0;i<max;i++){
  const label=String(i).padStart(2,'0');
  items.push(`<div class="time-wheel-option" data-wheel-value="${i}">${label}</div>`);
 }
 items.push('<div class="time-wheel-spacer"></div>');
 el.innerHTML=items.join('');
 el.style.scrollSnapType='none';
 el.scrollTop=0;
 el.querySelectorAll('[data-wheel-value]').forEach(item=>item.onclick=()=>{
  const target=Number(item.dataset.wheelValue)*44;
  el.style.scrollSnapType='none';
  el.scrollTo({top:target,behavior:'smooth'});
 });
 el.onscroll=()=>updateTimeWheelSelection(id);
}
function updateTimeWheelSelection(id){
 const el=$(id);if(!el)return;
 const value=Math.max(0,Math.min(el.querySelectorAll('[data-wheel-value]').length-1,Math.round(el.scrollTop/44)));
 el.querySelectorAll('[data-wheel-value]').forEach(item=>item.classList.toggle('selected',Number(item.dataset.wheelValue)===value));
 if(id==='timeHourWheel')timeWheelValue.hour=value;else timeWheelValue.minute=value;
}
function openEventTimePicker(){
 const field=$('eventTime');
 const raw=(field&&/^([01]\\d|2[0-3]):[0-5]\\d$/.test(field.value||''))?field.value:currentClockValue();
 const parts=raw.split(':').map(Number);
 timeWheelValue={
  hour:Number.isFinite(parts[0])?Math.max(0,Math.min(23,parts[0])):0,
  minute:Number.isFinite(parts[1])?Math.max(0,Math.min(59,parts[1])):0
 };
 const overlay=$('eventTimeWheel');
 if(!overlay)return;
 buildTimeWheel('timeHourWheel',24,timeWheelValue.hour);
 buildTimeWheel('timeMinuteWheel',60,timeWheelValue.minute);
 overlay.classList.add('open');
 overlay.style.display='flex';
 overlay.setAttribute('aria-hidden','false');
 document.documentElement.classList.add('time-picker-open');
 document.body.classList.add('time-picker-open');
 // Wait for the overlay and wheel columns to be laid out before setting scroll positions.
 const placeWheels=()=>{
  const h=$('timeHourWheel'),m=$('timeMinuteWheel');
  if(!h||!m)return;
  h.style.scrollSnapType='none';m.style.scrollSnapType='none';
  h.scrollTop=timeWheelValue.hour*44;
  m.scrollTop=timeWheelValue.minute*44;
  requestAnimationFrame(()=>{
   h.scrollTop=timeWheelValue.hour*44;
   m.scrollTop=timeWheelValue.minute*44;
   updateTimeWheelSelection('timeHourWheel');
   updateTimeWheelSelection('timeMinuteWheel');
   requestAnimationFrame(()=>{
    h.style.scrollSnapType='y mandatory';
    m.style.scrollSnapType='y mandatory';
   });
  });
 };
 requestAnimationFrame(()=>requestAnimationFrame(placeWheels));
}
function closeEventTimePicker(){
 const overlay=$('eventTimeWheel');
 if(!overlay)return;
 overlay.classList.remove('open');
 overlay.style.display='none';
 overlay.setAttribute('aria-hidden','true');
 document.body.classList.remove('time-picker-open');
 document.documentElement.classList.remove('time-picker-open');
}
const cancelTimeButton=$('cancelEventTime');
if(cancelTimeButton)cancelTimeButton.addEventListener('click',e=>{
 e.preventDefault();e.stopPropagation();closeEventTimePicker();
});
const confirmTimeButton=$('confirmEventTime');
if(confirmTimeButton)confirmTimeButton.addEventListener('click',e=>{
 e.preventDefault();e.stopPropagation();
 const field=$('eventTime');
 if(field){
  field.value=String(timeWheelValue.hour).padStart(2,'0')+':'+String(timeWheelValue.minute).padStart(2,'0');
  field.dispatchEvent(new Event('input',{bubbles:true}));
  field.dispatchEvent(new Event('change',{bubbles:true}));
 }
 closeEventTimePicker();
});
const timeWheelOverlay=$('eventTimeWheel');
if(timeWheelOverlay)timeWheelOverlay.addEventListener('click',e=>{
 if(e.target===timeWheelOverlay)closeEventTimePicker();
});
document.addEventListener('keydown',e=>{
 if(e.key==='Escape' && $('eventTimeWheel')?.classList.contains('open'))closeEventTimePicker();
});


const dateWheelState={day:1,month:1,year:new Date().getFullYear()};
const monthNames=['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
function daysInMonth(y,m){return new Date(y,m,0).getDate()}
function buildDateWheel(id,values,selected,fmt){const el=$(id);el.innerHTML='<div class="date-spacer"></div>'+values.map(v=>`<div class="date-option" data-value="${v}">${fmt?fmt(v):v}</div>`).join('')+'<div class="date-spacer"></div>';el.querySelectorAll('[data-value]').forEach(o=>o.onclick=()=>el.scrollTo({top:(Number(o.dataset.value)-values[0])*44,behavior:'smooth'}));const target=Math.max(0,(selected-values[0])*44);el.style.scrollSnapType='none';el.scrollTop=target;requestAnimationFrame(()=>{el.scrollTop=target;requestAnimationFrame(()=>{el.scrollTop=target;el.style.scrollSnapType='y mandatory';updateDateWheel(id);});});updateDateWheel(id);el.onscroll=()=>updateDateWheel(id)}
function updateDateWheel(id){const el=$(id),opts=[...el.querySelectorAll('[data-value]')];if(!opts.length)return;const i=Math.max(0,Math.min(opts.length-1,Math.round(el.scrollTop/44)));opts.forEach((o,n)=>o.classList.toggle('selected',i===n));const v=Number(opts[i].dataset.value);if(id==='dateDayWheel')dateWheelState.day=v;if(id==='dateMonthWheel')dateWheelState.month=v;if(id==='dateYearWheel')dateWheelState.year=v}
function refreshDateWheel(){dateWheelState.day=Math.min(dateWheelState.day,daysInMonth(dateWheelState.year,dateWheelState.month));buildDateWheel('dateDayWheel',Array.from({length:daysInMonth(dateWheelState.year,dateWheelState.month)},(_,i)=>i+1),dateWheelState.day,v=>String(v).padStart(2,'0'));buildDateWheel('dateMonthWheel',Array.from({length:12},(_,i)=>i+1),dateWheelState.month,v=>monthNames[v-1]);const y=dateWheelState.year;buildDateWheel('dateYearWheel',Array.from({length:323},(_,i)=>1900+i),y,v=>String(v))}
function openEventDatePicker(){const now=new Date(),raw=$('eventDate').value||dayKey(now),p=raw.split('-').map(Number);dateWheelState.year=(p.length===3&&p[0]>=1900&&p[0]<=2222)?p[0]:now.getFullYear();dateWheelState.month=(p.length===3&&p[1]>=1&&p[1]<=12)?p[1]:now.getMonth()+1;dateWheelState.day=(p.length===3&&p[2]>=1&&p[2]<=31)?p[2]:now.getDate();refreshDateWheel();const overlay=$('eventDateWheel');overlay.classList.add('open');overlay.setAttribute('aria-hidden','false');requestAnimationFrame(()=>requestAnimationFrame(()=>{[['dateDayWheel',dateWheelState.day-1],['dateMonthWheel',dateWheelState.month-1],['dateYearWheel',dateWheelState.year-1900]].forEach(([id,index])=>{const el=$(id);if(el){el.style.scrollSnapType='none';el.scrollTop=index*44;requestAnimationFrame(()=>{el.scrollTop=index*44;el.style.scrollSnapType='y mandatory';updateDateWheel(id);});}});}));}
function closeEventDatePicker(){$('eventDateWheel').classList.remove('open');$('eventDateWheel').setAttribute('aria-hidden','true')}
$('cancelEventDate').onclick=closeEventDatePicker;
$('confirmEventDate').onclick=()=>{dateWheelState.day=Math.min(dateWheelState.day,daysInMonth(dateWheelState.year,dateWheelState.month));const iso=dateWheelState.year+'-'+String(dateWheelState.month).padStart(2,'0')+'-'+String(dateWheelState.day).padStart(2,'0');$('eventDate').value=iso;$('eventDateDisplay').value=String(dateWheelState.day).padStart(2,'0')+'.'+String(dateWheelState.month).padStart(2,'0')+'.'+dateWheelState.year;closeEventDatePicker()};
$('eventDateWheel').addEventListener('click',e=>{if(e.target===$('eventDateWheel'))closeEventDatePicker()});
$('dateMonthWheel').addEventListener('touchend',()=>setTimeout(()=>{const max=daysInMonth(dateWheelState.year,dateWheelState.month);if(dateWheelState.day>max){dateWheelState.day=max;buildDateWheel('dateDayWheel',Array.from({length:max},(_,i)=>i+1),max,v=>String(v).padStart(2,'0'))}},100),{passive:true});
let colorPickerTarget='folder',colorPickerValue='#399B68';
function hexToHsl(hex){let r=parseInt(hex.slice(1,3),16)/255,g=parseInt(hex.slice(3,5),16)/255,b=parseInt(hex.slice(5,7),16)/255,max=Math.max(r,g,b),min=Math.min(r,g,b),h=0,s=0,l=(max+min)/2,d=max-min;if(d){s=d/(1-Math.abs(2*l-1));switch(max){case r:h=((g-b)/d)%6;break;case g:h=(b-r)/d+2;break;default:h=(r-g)/d+4}h*=60;if(h<0)h+=360}return{h:Math.round(h),s:Math.round(s*100),l:Math.round(l*100)}}
function hslHex(h,s,l){s/=100;l/=100;let c=(1-Math.abs(2*l-1))*s,x=c*(1-Math.abs((h/60)%2-1)),m=l-c/2,r=0,g=0,b=0;if(h<60){r=c;g=x}else if(h<120){r=x;g=c}else if(h<180){g=c;b=x}else if(h<240){g=x;b=c}else if(h<300){r=x;b=c}else{r=c;b=x}return '#'+[r,g,b].map(v=>Math.round((v+m)*255).toString(16).padStart(2,'0')).join('').toUpperCase()}
function updateCustomColorUI(){let h=+$('colorHue').value,s=+$('colorSat').value,l=+$('colorLight').value;colorPickerValue=hslHex(h,s,l);$('customColorPreview').style.background=colorPickerValue;$('hueValue').textContent=h+'°';$('satValue').textContent=s+'%';$('lightValue').textContent=l+'%'}
function openCustomColorPicker(target,initial){openNoteColorPicker(target,initial)}
['colorHue','colorSat','colorLight'].forEach(id=>$(id).addEventListener('input',updateCustomColorUI));
$('cancelCustomColor').onclick=()=>{$('customColorModal').classList.remove('open');$('customColorModal').setAttribute('aria-hidden','true')};
$('confirmCustomColor').onclick=()=>{if(colorPickerTarget==='folder'){selectedColor=colorPickerValue;renderPalette()}else setEventColor(colorPickerValue);$('customColorModal').classList.remove('open');$('customColorModal').setAttribute('aria-hidden','true')};
$('saveCustomColor').onclick=()=>{
 const list=colorPickerTarget==='folder'?db.folderColors:db.eventColors;
 if(!list.includes(colorPickerValue))list.push(colorPickerValue);
 save();
 if(colorPickerTarget==='folder')renderPalette();else renderEventSavedColors();
 toast('Цвет сохранён');
};
$('folderCustomColorBtn').onclick=()=>openCustomColorPicker('folder',selectedColor);
$('eventCustomColorBtn').onclick=()=>openCustomColorPicker('event',selectedEventColor);

function editCalendarEvent(id){
 const ev=id?db.events.find(x=>x.id===id):null;editingCalendarEvent=id||null;
 $('eventModalTitle').textContent=ev?'Изменить событие':'Новое событие';
 $('eventTitle').value=ev?.title||'';
 const nowForNewEvent=new Date();
 const initialEventDate=ev?.date||dayKey(nowForNewEvent);
 $('eventDate').value=initialEventDate;
 const initialDateParts=initialEventDate.split('-').map(Number);
 $('eventDateDisplay').value=initialDateParts.length===3
  ?String(initialDateParts[2]).padStart(2,'0')+'.'+String(initialDateParts[1]).padStart(2,'0')+'.'+initialDateParts[0]
  :'';
 $('eventTime').value=ev?.time||currentClockValue();
 $('eventDescription').value=ev?.description||'';
 $('eventRepeat').value=ev?.repeat||'none';
 $('eventReminder').value=String(ev?.reminder??0);
 setEventColor(ev?.color??'#D69B45');renderEventSavedColors();
 $('deleteEvent').style.display=ev?'block':'none';
 openModal('eventModal');
}

window.openReminderEvent=function(id){
 const ev=(db.events||[]).find(x=>String(x.id)===String(id));
 if(!ev){console.warn('Reminder event not found',id);return false}
 const p=(ev.date||'').split('-').map(Number);
 if(p.length===3&&p.every(Number.isFinite)){
  calendarSelected=new Date(p[0],p[1]-1,p[2]);
  calendarCursor=new Date(p[0],p[1]-1,1);
 }
 setBottomTab('calendar');
 renderCalendar();
 setTimeout(()=>editCalendarEvent(ev.id),180);
 return true;
};

let selectedCalendarNoteFolder='__root__';
let calendarNoteFolderOptions=[];
function renderCalendarNoteFolderList(){
 $('calendarNoteFolderList').innerHTML=calendarNoteFolderOptions.map(o=>`
 <button type="button" class="move-destination-option ${o.value===selectedCalendarNoteFolder?'selected':''}" data-calendar-note-folder="${esc(o.value)}" role="option" aria-selected="${o.value===selectedCalendarNoteFolder}">
  <span class="move-folder-icon">${o.value==='__root__'?'⌂':'📁'}</span>
  <span class="move-folder-name">${esc(o.value==='__root__'?'Главная':o.label)}${o.path?`<small class="move-folder-path">${esc(o.path)}</small>`:''}</span>
  <span class="move-check"></span>
 </button>`).join('');
 $('calendarNoteFolderList').querySelectorAll('[data-calendar-note-folder]').forEach(b=>b.onclick=()=>{
  selectedCalendarNoteFolder=b.dataset.calendarNoteFolder;renderCalendarNoteFolderList();
 });
}
function openCalendarNoteFolderPicker(){
 const options=[{value:'__root__',label:'Главная',path:''}];
 function addChildren(parent){
  db.folders.filter(f=>f.parentId===parent&&!f.deletedAt).sort((a,b)=>a.name.localeCompare(b.name,'ru')).forEach(f=>{
   options.push({value:f.id,label:f.name,path:folderPath(f.id).map(x=>x.name).join(' › ')});
   addChildren(f.id);
  });
 }
 addChildren(null);
 calendarNoteFolderOptions=options;
 selectedCalendarNoteFolder='__root__';
 renderCalendarNoteFolderList();
 openModal('calendarNoteFolderModal');
}
$('addCalendarNote').onclick=openCalendarNoteFolderPicker;
$('cancelCalendarNoteFolder').onclick=()=>closeModal('calendarNoteFolderModal');
$('confirmCalendarNoteFolder').onclick=()=>{
 const folderId=selectedCalendarNoteFolder==='__root__'?null:selectedCalendarNoteFolder;
 closeModal('calendarNoteFolderModal');
 editNote(null,folderId);
};
$('addCalendarEvent').onclick=()=>editCalendarEvent(null);
$('cancelEvent').onclick=()=>closeModal('eventModal');
$('saveEvent').onclick=()=>{
 const title=$('eventTitle').value.trim(),date=$('eventDate').value;
 if(!title){toast('Введи название события');$('eventTitle').focus();return}
 if(!date){toast('Выбери дату события');return}
 const data={title,date,time:$('eventTime').value,description:$('eventDescription').value.trim(),repeat:$('eventRepeat').value,reminder:Number($('eventReminder').value),color:selectedEventColor};
 if(editingCalendarEvent){const ev=db.events.find(x=>x.id===editingCalendarEvent);if(ev)Object.assign(ev,data)}
 else db.events.push({id:uid(),...data,createdAt:Date.now()});
 save();scanCalendarReminders();const [yy,mm,dd]=date.split('-').map(Number);calendarSelected=new Date(yy,mm-1,dd);calendarCursor=new Date(yy,mm-1,1);
 closeModal('eventModal');renderCalendar();toast('Событие сохранено');
};
$('deleteEvent').onclick=()=>{
 if(!editingCalendarEvent||!confirm('Удалить это событие?'))return;
 db.events=db.events.filter(x=>x.id!==editingCalendarEvent);save();closeModal('eventModal');renderCalendar();toast('Событие удалено');
};
$('calendarPrev').onclick=()=>{calendarCursor.setMonth(calendarCursor.getMonth()-1);renderCalendar()};
$('calendarNext').onclick=()=>{calendarCursor.setMonth(calendarCursor.getMonth()+1);renderCalendar()};
$('calendarNav').onclick=()=>{setBottomTab('calendar');renderCalendar();pushNavigation()};
$('homeNav').onclick=()=>{setBottomTab('home');allMode=false;currentFolder=null;render();pushNavigation()};
$('musicNav').onclick=()=>{setBottomTab('music');pushNavigation()};
$('openTrashSettings').onclick=()=>{closeModal('settingsModal');renderTrash();openModal('trashModal')};

function currentHomeOrder(){return db.homeOrder[currentFolder||'root']||[]}

function homeItemSize(el){
 const photo=el.dataset.photo?db.photos.find(x=>x.id===el.dataset.photo):null;
 const size=photo?Number(photo.size||1):1;
 return size===2?{w:2,h:1}:size===3?{w:1,h:2}:size===4?{w:2,h:2}:{w:1,h:1};
}
function homeKey(){return currentFolder||'root'}
function getHomeItems(){
 return [...$('folderGrid').querySelectorAll('[data-layout-item]')].map(el=>({el,key:el.dataset.layoutItem,...homeItemSize(el)}));
}
function homeFits(occ,col,row,w,h,ignoreKey=null){
 if(col<1||col+w-1>3||row<1)return false;
 for(let y=row;y<row+h;y++)for(let x=col;x<col+w;x++){
  const k=occ[y+':'+x];if(k&&k!==ignoreKey)return false;
 }
 return true;
}
function occupyHome(occ,col,row,w,h,key){
 for(let y=row;y<row+h;y++)for(let x=col;x<col+w;x++)occ[y+':'+x]=key;
}
function homePositions(items){
 const saved=db.homeSlots&&db.homeSlots[homeKey()]||{};
 const occ={},pos={};
 // Preserve all valid saved positions, including intentionally empty cells.
 items.forEach(it=>{
  const p=saved[it.key];
  if(p&&homeFits(occ,Number(p.col),Number(p.row),it.w,it.h)){
   pos[it.key]={col:Number(p.col),row:Number(p.row)};
   occupyHome(occ,pos[it.key].col,pos[it.key].row,it.w,it.h,it.key);
  }
 });
 // Place only genuinely new items into the first available footprint, scanning row by row.
 items.forEach(it=>{
  if(pos[it.key])return;
  let row=1,col=1,guard=0;
  while(!homeFits(occ,col,row,it.w,it.h)&&guard++<10000){
   col++;if(col>3){col=1;row++;}
  }
  pos[it.key]={col,row};
  occupyHome(occ,col,row,it.w,it.h,it.key);
 });
 return pos;
}
function nextHomeCell(occ,w,h,startRow=1){
 let row=startRow,col=1,guard=0;
 while(!homeFits(occ,col,row,w,h)&&guard++<10000){
  col++;if(col>3){col=1;row++;}
 }
 return {col,row};
}
function placeItem(key,col,row){
 const items=getHomeItems();
 const moving=items.find(it=>it.key===key);
 if(!moving)return;
 col=Math.max(1,Math.min(4-moving.w,Math.round(Number(col)||1)));
 row=Math.max(1,Math.round(Number(row)||1));
 const current=homePositions(items),occ={},next={};
 // Reserve the requested destination for the moving item first.
 next[key]={col,row};
 occupyHome(occ,col,row,moving.w,moving.h,key);
 // Keep every other item in its saved cell if possible. Only collisions are moved,
 // and they are sent to the nearest first-fit free cell without compacting unrelated gaps.
 items.filter(it=>it.key!==key).forEach(it=>{
  const p=current[it.key];
  if(p&&homeFits(occ,p.col,p.row,it.w,it.h)){
   next[it.key]={col:p.col,row:p.row};
   occupyHome(occ,p.col,p.row,it.w,it.h,it.key);
  }else{
   const dest=nextHomeCell(occ,it.w,it.h,1);
   next[it.key]=dest;
   occupyHome(occ,dest.col,dest.row,it.w,it.h,it.key);
  }
 });
 db.homeSlots=db.homeSlots||{};
 db.homeSlots[homeKey()]=next;
 db.homeOrder=db.homeOrder||{};
 db.homeOrder[homeKey()]=items.map(it=>it.key);
 save();
 render();
}
function applyHomePositions(){
 const grid=$('folderGrid'),items=getHomeItems(),pos=homePositions(items);
 grid.style.gridAutoFlow='row';
 items.forEach(it=>{
  const p=pos[it.key];it.el.style.gridColumn=`${p.col} / span ${it.w}`;
  it.el.style.gridRow=`${p.row} / span ${it.h}`;
 });
}
function persistHomeOrder(){
 const items=getHomeItems(),pos=homePositions(items);
 db.homeSlots=db.homeSlots||{};
 db.homeSlots[homeKey()]=pos;
 db.homeOrder=db.homeOrder||{};
 db.homeOrder[homeKey()]=items.map(it=>it.key);
 save();
}
function bindHomeDrag(){
 const grid=$('folderGrid');
 let active=null,timer=null,dragging=false,pointerId=null,offsetX=0,offsetY=0,ghost=null,startX=0,startY=0;
 const stopTimer=()=>{if(timer){clearTimeout(timer);timer=null}};
 const removeListeners=()=>{
  document.removeEventListener('pointermove',onMove,true);
  document.removeEventListener('pointerup',onUp,true);
  document.removeEventListener('pointercancel',onCancel,true);
 };
 const clear=()=>{
  stopTimer();removeListeners();
  if(active){active.el.classList.remove('dragging');active.el.style.visibility=''}
  if(ghost)ghost.remove();
  document.body.classList.remove('home-layout-dragging');
  ghost=null;active=null;dragging=false;pointerId=null;
 };
 const createGhost=(el,r)=>{
  ghost=el.cloneNode(true);
  ghost.removeAttribute('data-layout-item');ghost.removeAttribute('data-folder');ghost.removeAttribute('data-photo');
  ghost.querySelectorAll('button').forEach(b=>b.remove());
  ghost.style.cssText=`position:fixed;z-index:9999;left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px;margin:0;pointer-events:none;opacity:.94;transform:none;box-shadow:0 10px 24px rgba(0,0,0,.18);border-radius:18px;outline:none`;
  document.body.appendChild(ghost);
 };
 const targetAt=(x,y)=>{
  const r=grid.getBoundingClientRect(),cs=getComputedStyle(grid);
  const gap=parseFloat(cs.columnGap)||10,rowGap=parseFloat(cs.rowGap)||10;
  const cols=3,cellW=(r.width-gap*(cols-1))/cols;
  const cellH=parseFloat(cs.gridAutoRows)||105;
  const pitchX=cellW+gap,pitchY=cellH+rowGap;
  const sz=homeItemSize(active.el);
  const centerX=x-offsetX+ghost.offsetWidth/2;
  const centerY=y-offsetY+ghost.offsetHeight/2;
  let col=Math.floor((centerX-r.left)/pitchX)+1;
  let row=Math.floor((centerY-r.top)/pitchY)+1;
  col=Math.max(1,Math.min(cols-sz.w+1,col));
  row=Math.max(1,row);
  return {col,row};
 };
 const onMove=e=>{
  if(!active||e.pointerId!==pointerId)return;
  if(!dragging){
   if(Math.hypot(e.clientX-startX,e.clientY-startY)>18){stopTimer();clear()}
   return;
  }
  e.preventDefault();
  ghost.style.left=(e.clientX-offsetX)+'px';
  ghost.style.top=(e.clientY-offsetY)+'px';
  active.target=targetAt(e.clientX,e.clientY);
 };
 const onUp=e=>{
  if(!active||e.pointerId!==pointerId)return;
  e.preventDefault();stopTimer();
  const key=active.key,target=active.target,wasDragging=dragging;
  clear();
  if(wasDragging&&target)placeItem(key,target.col,target.row);
 };
 const onCancel=()=>clear();
 grid.querySelectorAll('[data-layout-item]').forEach(el=>{
  if(el.dataset.dragBound==='launcher-v3')return;
  el.dataset.dragBound='launcher-v3';
  el.addEventListener('contextmenu',e=>{if(layoutEditing){e.preventDefault();e.stopPropagation()}});
  el.addEventListener('pointerdown',e=>{
   if(!layoutEditing||e.target.closest('button'))return;
   if(e.pointerType==='mouse'&&e.button!==0)return;
   e.preventDefault();
   const r=el.getBoundingClientRect();
   active={el,key:el.dataset.layoutItem,target:null};
   pointerId=e.pointerId;offsetX=e.clientX-r.left;offsetY=e.clientY-r.top;startX=e.clientX;startY=e.clientY;
   document.addEventListener('pointermove',onMove,true);
   document.addEventListener('pointerup',onUp,true);
   document.addEventListener('pointercancel',onCancel,true);
   timer=setTimeout(()=>{
    timer=null;if(!active)return;
    dragging=true;document.body.classList.add('home-layout-dragging');
    el.classList.add('dragging');el.style.visibility='hidden';
    createGhost(el,r);
    active.target=targetAt(startX,startY);
   },380);
  },{passive:false});
 });
}
function openPhotoActions(id){const ph=db.photos.find(x=>x.id===id);if(!ph)return;activePhotoId=id;$('photoActionsTitle').textContent=ph.name||'Фотография';$('photoActionsPreview').src=ph.data;document.querySelectorAll('[data-photo-size]').forEach(b=>b.classList.toggle('selected',Number(b.dataset.photoSize)===Number(ph.size||1)));openModal('photoActionsModal')}
function readAndCompressImage(file){return new Promise((resolve,reject)=>{if(!file||!file.type.startsWith('image/'))return reject(new Error('Выбери изображение'));const reader=new FileReader();reader.onerror=()=>reject(new Error('Не удалось прочитать фото'));reader.onload=()=>{const img=new Image();img.onerror=()=>reject(new Error('Не удалось открыть фото'));img.onload=()=>{const max=1100,scale=Math.min(1,max/Math.max(img.width,img.height));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);resolve(canvas.toDataURL('image/jpeg',.76))};img.src=reader.result};reader.readAsDataURL(file)})}
$('addPhotoTop').onclick=()=>{photoReplaceTarget=null;$('homePhotoInput').value='';$('homePhotoInput').click()};
$('homePhotoInput').onchange=async e=>{const files=[...(e.target.files||[])];if(!files.length)return;if(photoReplaceTarget){const file=files[0];const target=photoReplaceTarget;photoReplaceTarget=null;try{const data=await readAndCompressImage(file);const ph=db.photos.find(x=>x.id===target);if(ph){const old=ph.data,oldName=ph.name;ph.data=data;ph.name=file.name.replace(/\.[^.]+$/,'');const linked=db.notes.find(n=>n.id===ph.noteId);if(linked){if(!linked.title||linked.title===oldName)linked.title=ph.name;linked.updatedAt=Date.now()}try{save()}catch(err){ph.data=old;throw err}render();openPhotoActions(ph.id);toast('Фотография заменена')}}catch(err){toast('Не удалось заменить фотографию')}return}for(const file of files){try{const data=await readAndCompressImage(file);const ph={id:uid(),parentId:currentFolder,name:file.name.replace(/\.[^.]+$/,''),data,size:1,createdAt:Date.now()};db.photos.push(ph);ensurePhotoNotes();try{save()}catch(err){db.photos=db.photos.filter(x=>x.id!==ph.id);db.notes=db.notes.filter(n=>n.photoId!==ph.id);toast('Не хватило места для фото. Попробуй снимок меньшего размера.');break}}catch(err){toast(err.message||'Ошибка добавления фото')}}render();if(files.length)toast('Фотографии добавлены')};
document.querySelectorAll('[data-photo-size]').forEach(b=>b.onclick=()=>{const ph=db.photos.find(x=>x.id===activePhotoId);if(!ph)return;ph.size=Number(b.dataset.photoSize);try{save();render();openPhotoActions(ph.id)}catch(e){toast('Не удалось сохранить размер')}});
$('movePhotoBtn').onclick=()=>{
 if(!activePhotoId)return;
 const ph=db.photos.find(x=>x.id===activePhotoId);if(!ph)return;
 currentFolder=ph.parentId??null;
 closeModal('photoActionsModal');
 layoutEditing=true;render();
 toast('Перемести фотографию пальцем по сетке и нажми «Готово»');
};
$('replacePhotoBtn').onclick=()=>{photoReplaceTarget=activePhotoId;$('homePhotoInput').value='';$('homePhotoInput').click()};
$('removePhotoBtn').onclick=()=>{if(!activePhotoId)return;const removedPhoto=db.photos.find(x=>x.id===activePhotoId);db.photos=db.photos.filter(x=>x.id!==activePhotoId);if(removedPhoto?.noteId)db.notes=db.notes.filter(n=>n.id!==removedPhoto.noteId);db.homeOrder=Object.fromEntries(Object.entries(db.homeOrder).map(([k,v])=>[k,(v||[]).filter(x=>x!=='photo:'+activePhotoId)]));save();closeModal('photoActionsModal');render();toast('Фотография убрана с главной')};
$('layoutEditToggle').onclick=()=>{layoutEditing=!layoutEditing;if(!layoutEditing)persistHomeOrder();render()};
$('layoutDoneButton').onclick=()=>{layoutEditing=false;persistHomeOrder();render();toast('Расположение сохранено')};
$('closePhotoLightbox').onclick=()=>$('photoLightbox').classList.remove('show');$('photoLightbox').onclick=e=>{if(e.target===$('photoLightbox'))$('photoLightbox').classList.remove('show')};
$('addFolderTop').onclick=()=>editFolder();$('addNoteTop').onclick=()=>editNote();let searchScope='current';
$('searchInput').oninput=render;
function updateScopePicker(){
 $('scopeLabel').textContent=searchScope==='all'?'Во всех папках':'В этой области';
 $('scopeMenu').querySelectorAll('[data-scope]').forEach(b=>b.classList.toggle('active',b.dataset.scope===searchScope));
}
$('scopeTrigger').onclick=e=>{
 e.stopPropagation();
 const menu=$('scopeMenu'),opening=menu.classList.contains('hidden');
 menu.classList.toggle('hidden');
 $('scopeTrigger').setAttribute('aria-expanded',String(opening));
};
$('scopeMenu').querySelectorAll('[data-scope]').forEach(b=>b.onclick=e=>{
 e.stopPropagation();searchScope=b.dataset.scope;updateScopePicker();
 $('scopeMenu').classList.add('hidden');$('scopeTrigger').setAttribute('aria-expanded','false');render();
});
document.addEventListener('click',e=>{
 if(!e.target.closest('#scopePicker')){$('scopeMenu').classList.add('hidden');$('scopeTrigger').setAttribute('aria-expanded','false')}
});
$('searchToggle').onclick=()=>{const bar=$('searchBar');bar.classList.toggle('hidden');if(!bar.classList.contains('hidden'))$('searchInput').focus();else{$('searchInput').value='';searchScope='current';updateScopePicker();render()}};
$('settingsBtn').onclick=()=>{ $('backupStatus').textContent='В копию войдут все папки, заметки, фотографии и вложения.'; $('languageSelect').value=localStorage.getItem('shkafchik_language')||'ru'; openModal('settingsModal'); applyLanguage() };
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>closeModal(b.dataset.close));

function makeBackup(){
 try{
  // Keep every current database field, including calendar events and future additions.
  const snapshot=JSON.parse(JSON.stringify(db));
  const payload={
   app:'Шкафчик',
   backupFormat:2,
   createdAt:new Date().toISOString(),
   appVersion:'0.2.20',
   data:snapshot
  };
  const stamp=new Date().toISOString().replace(/[:.]/g,'-');
  const filename='shkafchik-backup-'+stamp+'.json';
  const json=JSON.stringify(payload);
  if(window.AndroidAPI && typeof window.AndroidAPI.saveBackup==='function'){
   $('backupStatus').textContent='Выбери папку и имя файла для сохранения копии.';
   window.AndroidAPI.saveBackup(filename,json);
  }else{
   const blob=new Blob([json],{type:'application/json;charset=utf-8'});
   const url=URL.createObjectURL(blob);
   const a=document.createElement('a');
   a.href=url;a.download=filename;
   document.body.appendChild(a);a.click();a.remove();
   setTimeout(()=>URL.revokeObjectURL(url),3000);
   $('backupStatus').textContent='Копия подготовлена для скачивания.';
  }
  
 }catch(err){
  console.error(err);
  $('backupStatus').textContent='Не удалось создать резервную копию. Проверь свободное место.';
  toast('Ошибка создания копии');
 }
}
window.nativeBackupSaveResult=function(success,message){
 const status=$('backupStatus');
 if(status)status.textContent=message;
 if(success)toast('Резервная копия сохранена');
 else if(message && message.indexOf('отменено')<0)toast('Не удалось сохранить копию');
};
function normalizeBackup(obj){
 if(!obj || typeof obj!=='object')return null;
 // Current envelope, older envelope, or raw database JSON are accepted.
 let source=obj.data && typeof obj.data==='object' ? obj.data : obj;
 const folders=Array.isArray(source.folders)?source.folders:null;
 const notes=Array.isArray(source.notes)?source.notes:null;
 if(!folders || !notes)return null;
 const normalized={...source,folders,notes,
  trash:Array.isArray(source.trash)?source.trash:[],
  events:Array.isArray(source.events)?source.events:[],
  photos:Array.isArray(source.photos)?source.photos:[],
  homeOrder:source.homeOrder&&typeof source.homeOrder==='object'?source.homeOrder:{}
 };
 return normalized;
}
$('exportBackupBtn').onclick=makeBackup;
$('importBackupBtn').onclick=()=>{
 $('backupFileInput').value='';
 $('backupFileInput').click();
};
$('backupFileInput').onchange=async e=>{
 const file=e.target.files && e.target.files[0];
 if(!file)return;
 try{
  if(file.size>100*1024*1024){
   $('backupStatus').textContent='Файл слишком большой (более 100 МБ).';
   toast('Слишком большой файл');return;
  }
  const parsed=JSON.parse(await file.text());
  const restored=normalizeBackup(parsed);
  if(!restored){
   $('backupStatus').textContent='Не удалось распознать формат. Текущие данные не изменены.';
   toast('Неподходящий файл резервной копии');return;
  }
  const counts=`${restored.folders.length} папок, ${restored.notes.length} заметок и ${restored.events.length} событий календаря`;
  if(!confirm(`Восстановить копию: ${counts}? Текущие данные будут заменены. Сначала рекомендуется сохранить отдельную копию.`))return;
  // Do not mutate in-memory or stored data until parsing and validation have succeeded.
  const serialized=JSON.stringify(restored);
  localStorage.setItem('shkafchik_db',serialized);
  db=restored;ensurePhotoNotes();
  currentFolder=null;editingFolder=null;editingNote=null;viewingNote=null;allMode=false;trashMode=false;
  save();
  render();
  $('backupStatus').textContent='Данные успешно восстановлены. Проверь папки, заметки и календарь.';
  toast('Резервная копия восстановлена');
  closeModal('settingsModal');
 }catch(err){
  console.error(err);
  $('backupStatus').textContent='Не удалось прочитать или сохранить файл. Текущие данные не должны быть изменены.';
  toast('Ошибка чтения резервной копии');
 }
};
function cleanupTrash(){let cutoff=Date.now()-30*86400000;let old=db.trash.filter(t=>t.deletedAt<cutoff);old.forEach(t=>{if(t.type==='note')db.notes=db.notes.filter(n=>n.id!==t.id);else db.folders=db.folders.filter(f=>f.id!==t.id)});db.trash=db.trash.filter(t=>t.deletedAt>=cutoff);if(old.length)save()}
cleanupTrash();startReminderScanner();
render();history.replaceState({shkafchik:navSnapshot()},'','#app');
