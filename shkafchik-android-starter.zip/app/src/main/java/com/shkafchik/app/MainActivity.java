package com.shkafchik.app;
import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import java.io.OutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileChooserCallback;
    private String pendingBackupJson;
    private static final int REQUEST_IMPORT = 4101, REQUEST_EXPORT = 4102;
    private static final String CHANNEL = "shkafchik_events";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ReminderReceiver.createChannel(this);
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(246, 246, 244));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().setNavigationBarColor(Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            web.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(0, bars.top, 0, bars.bottom);
                return insets;
            });
        } else {
            getWindow().setStatusBarColor(Color.rgb(246, 246, 244));
            getWindow().setNavigationBarColor(Color.WHITE);
            web.setFitsSystemWindows(true);
        }
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.postDelayed(() -> syncEventsFromPage(), 700);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES,
                    new String[]{"application/json", "text/json", "text/plain"});
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(intent, REQUEST_IMPORT);
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidAPI");
        setContentView(web);
        if (Build.VERSION.SDK_INT >= 30) web.requestApplyInsets();
        web.loadUrl("file:///android_asset/index.html");
    }

    private void syncEventsFromPage() {
        if (web != null) web.evaluateJavascript(
            "(function(){try{if(typeof db!=='undefined'&&window.AndroidAPI)AndroidAPI.syncReminders(JSON.stringify(db.events||[]));}catch(e){}})();", null);
    }

    public class Bridge {
        @JavascriptInterface public void showNotification(String title, String message) {
            runOnUiThread(() -> {
                Notification n = new Notification.Builder(MainActivity.this, CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(title).setContentText(message).setAutoCancel(true).build();
                getSystemService(NotificationManager.class).notify(
                    (int)(System.currentTimeMillis() & 0x7fffffff), n);
            });
        }
        @JavascriptInterface public void syncReminders(String eventsJson) {
            ReminderReceiver.saveAndSchedule(MainActivity.this, eventsJson);
        }
        @JavascriptInterface public void saveBackup(String filename, String json) {
            runOnUiThread(() -> {
                pendingBackupJson = json == null ? "{}" : json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE,
                    filename == null || filename.trim().isEmpty() ? "shkafchik-backup.json" : filename);
                startActivityForResult(intent, REQUEST_EXPORT);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMPORT) {
            Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null)
                ? new Uri[]{data.getData()} : null;
            if (fileChooserCallback != null) {
                fileChooserCallback.onReceiveValue(result);
                fileChooserCallback = null;
            }
        } else if (requestCode == REQUEST_EXPORT) {
            boolean ok = false;
            String message = "Сохранение отменено.";
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                try (OutputStream stream = getContentResolver().openOutputStream(data.getData(), "w")) {
                    if (stream == null) throw new IOException("Не удалось открыть файл");
                    stream.write(pendingBackupJson.getBytes("UTF-8"));
                    stream.flush();
                    ok = true;
                    message = "Резервная копия сохранена.";
                } catch (Exception e) { message = "Ошибка сохранения: " + e.getMessage(); }
            }
            pendingBackupJson = null;
            if (web != null) {
                final boolean success = ok; final String msg = message;
                web.post(() -> web.evaluateJavascript(
                    "window.nativeBackupSaveResult&&window.nativeBackupSaveResult(" + success + "," +
                    org.json.JSONObject.quote(msg) + ");", null));
            }
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (web != null) web.postDelayed(() -> syncEventsFromPage(), 500);
        ReminderReceiver.scheduleFromPrefs(this);
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
