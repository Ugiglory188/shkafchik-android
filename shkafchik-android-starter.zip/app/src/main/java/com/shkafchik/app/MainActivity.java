package com.shkafchik.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Notification;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;
    private static final String CHANNEL = "shkafchik_events";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ReminderReceiver.createChannel(this);
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript(
                    "(function(){try{if(typeof db!=='undefined'&&window.AndroidAPI)AndroidAPI.syncReminders(JSON.stringify(db.events||[]));}catch(e){console.log(e);}})();",
                    null);
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "AndroidAPI");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    public class Bridge {
        @JavascriptInterface public void showNotification(String title, String message) {
            runOnUiThread(() -> {
                Notification n = new Notification.Builder(MainActivity.this, CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(title).setContentText(message).setAutoCancel(true).build();
                getSystemService(NotificationManager.class).notify((int)(System.currentTimeMillis() & 0x7fffffff), n);
            });
        }

        @JavascriptInterface public void syncReminders(String eventsJson) {
            ReminderReceiver.saveAndSchedule(MainActivity.this, eventsJson);
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
