package com.shkafchik.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.app.TaskStackBuilder;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.HashSet;
import java.util.Set;

public class ReminderReceiver extends BroadcastReceiver {
    static final String PREFS = "calendar_reminders";
    static final String JSON_KEY = "events_json";
    static final String CHANNEL = "shkafchik_events";
    static final String ACTION = "com.shkafchik.app.EVENT_REMINDER";

    static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(
                CHANNEL, "Напоминания Шкафчика", NotificationManager.IMPORTANCE_HIGH));
        }
    }

    static void saveAndSchedule(Context c, String json) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(JSON_KEY, json).apply();
        scheduleAll(c, json);
    }

    static void scheduleFromPrefs(Context c) {
        String json = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(JSON_KEY, "[]");
        scheduleAll(c, json);
    }

    static void scheduleAll(Context c, String json) {
        createChannel(c);
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        android.content.SharedPreferences prefs = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> previouslyScheduled = prefs.getStringSet("scheduled_ids", new HashSet<String>());
        for (String oldId : previouslyScheduled) {
            PendingIntent old = pending(c, oldId, null, null, false);
            if (old != null) { am.cancel(old); old.cancel(); }
        }
        Set<String> scheduled = new HashSet<>();
        try {
            JSONArray events = new JSONArray(json == null ? "[]" : json);
            for (int i = 0; i < events.length(); i++) {
                JSONObject ev = events.optJSONObject(i);
                if (ev == null) continue;
                String id = ev.optString("id", "");
                if (id.isEmpty()) continue;
                if (ev.optBoolean("deleted", false)) continue;
                long at = nextReminder(ev);
                if (at <= System.currentTimeMillis()) continue;
                Intent intent = new Intent(c, ReminderReceiver.class).setAction(ACTION)
                    .putExtra("event_id", id)
                    .putExtra("title", ev.optString("title", "Напоминание"))
                    .putExtra("message", message(ev));
                PendingIntent pi = PendingIntent.getBroadcast(c, id.hashCode(), intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                } else if (Build.VERSION.SDK_INT >= 23) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                } else {
                    am.set(AlarmManager.RTC_WAKEUP, at, pi);
                }
                scheduled.add(id);
            }
            prefs.edit().putStringSet("scheduled_ids", scheduled).apply();
        } catch (Exception ignored) { }
    }

    private static PendingIntent pending(Context c, String id, String title, String msg, boolean create) {
        Intent intent = new Intent(c, ReminderReceiver.class).setAction(ACTION).putExtra("event_id", id);
        if (title != null) intent.putExtra("title", title);
        if (msg != null) intent.putExtra("message", msg);
        int flags = PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE;
        if (create) flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(c, id.hashCode(), intent, flags);
    }

    private static String message(JSONObject ev) {
        String desc = ev.optString("description", "");
        String time = ev.optString("time", "09:00");
        return (desc.isEmpty() ? "" : desc + " · ") + "Время: " + time;
    }

    private static long nextReminder(JSONObject ev) {
        try {
            String dateText = ev.optString("date", "");
            String[] d = dateText.split("-");
            if (d.length != 3) return -1;
            Calendar base = Calendar.getInstance();
            base.set(Integer.parseInt(d[0]), Integer.parseInt(d[1])-1, Integer.parseInt(d[2]), 12, 0, 0);
            base.set(Calendar.MILLISECOND, 0);
            String[] t = ev.optString("time", "09:00").split(":");
            int hour = Integer.parseInt(t[0]), minute = Integer.parseInt(t[1]);
            long lead = Math.max(0, ev.optLong("reminder", 0)) * 60000L;
            String repeat = ev.optString("repeat", "none");
            Calendar candidate = (Calendar)base.clone();
            long now = System.currentTimeMillis();
            for (int day = 0; day <= 3660; day++) {
                if (day > 0) candidate.add(Calendar.DAY_OF_MONTH, 1);
                if (!occurs(base, candidate, repeat)) continue;
                Calendar eventAt = (Calendar)candidate.clone();
                eventAt.set(Calendar.HOUR_OF_DAY, hour);
                eventAt.set(Calendar.MINUTE, minute);
                eventAt.set(Calendar.SECOND, 0);
                eventAt.set(Calendar.MILLISECOND, 0);
                long alarmAt = eventAt.getTimeInMillis() - lead;
                if (alarmAt > now + 1000) return alarmAt;
            }
        } catch (Exception ignored) { }
        return -1;
    }

    private static boolean occurs(Calendar base, Calendar date, String repeat) {
        if (date.before(base)) return false;
        switch (repeat) {
            case "daily": return true;
            case "weekly":
                java.time.LocalDate b = java.time.LocalDate.of(base.get(Calendar.YEAR), base.get(Calendar.MONTH)+1, base.get(Calendar.DAY_OF_MONTH));
                java.time.LocalDate d = java.time.LocalDate.of(date.get(Calendar.YEAR), date.get(Calendar.MONTH)+1, date.get(Calendar.DAY_OF_MONTH));
                return java.time.temporal.ChronoUnit.DAYS.between(b, d) % 7 == 0;
            case "monthly": return date.get(Calendar.DAY_OF_MONTH)==base.get(Calendar.DAY_OF_MONTH);
            case "yearly": return date.get(Calendar.DAY_OF_MONTH)==base.get(Calendar.DAY_OF_MONTH)
                && date.get(Calendar.MONTH)==base.get(Calendar.MONTH);
            default: return date.get(Calendar.YEAR)==base.get(Calendar.YEAR)
                && date.get(Calendar.DAY_OF_YEAR)==base.get(Calendar.DAY_OF_YEAR);
        }
    }

    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || !ACTION.equals(intent.getAction())) return;
        createChannel(context);
        String title = intent.getStringExtra("title");
        String message = intent.getStringExtra("message");
        String eventId = intent.getStringExtra("event_id");
        Intent openApp = new Intent(context, MainActivity.class)
            .putExtra("open_event_id", eventId)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(context,
            eventId == null ? 0 : eventId.hashCode(), openApp,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_shkafchik)
            .setContentIntent(contentIntent)
            .setContentTitle(title == null ? "Напоминание" : title)
            .setContentText(message == null ? "" : message)
            .setStyle(new Notification.BigTextStyle().bigText(message == null ? "" : message))
            .setAutoCancel(true).build();
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT < 33 ||
            context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            nm.notify((intent.getStringExtra("event_id") + System.currentTimeMillis()).hashCode(), n);
        }
        scheduleFromPrefs(context);
    }
}
